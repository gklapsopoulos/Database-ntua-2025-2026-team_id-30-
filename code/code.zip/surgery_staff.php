<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `surgery_staff` ORDER BY `staff_id`, `procedure_hospitalization_id` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Surgery Staff</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Surgery Staff</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_surgery_staff.php">Create Surgery Staff</a>
        <span class="muted">Showing up to 300 rows from surgery_staff</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>staff_id</th>
                    <th>procedure_hospitalization_id</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="3">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['staff_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['procedure_hospitalization_id'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_surgery_staff.php?staff_id=<?php echo urlencode($row['staff_id']); ?>&procedure_hospitalization_id=<?php echo urlencode($row['procedure_hospitalization_id']); ?>">Edit</a>
                                <a class="btn danger" href="delete_surgery_staff.php?staff_id=<?php echo urlencode($row['staff_id']); ?>&procedure_hospitalization_id=<?php echo urlencode($row['procedure_hospitalization_id']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
