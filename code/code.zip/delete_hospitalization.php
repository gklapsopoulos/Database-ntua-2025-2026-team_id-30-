<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $hospitalization_idKey = mysqli_real_escape_string($conn, $_POST['hospitalization_id'] ?? '');
    $where = "`hospitalization_id` = '$hospitalization_idKey'";
    $sql = "DELETE FROM `hospitalization` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: hospitalization.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $hospitalization_idKey = mysqli_real_escape_string($conn, $_GET['hospitalization_id'] ?? '');
    $where = "`hospitalization_id` = '$hospitalization_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `hospitalization` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Hospitalization</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Hospitalization</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="hospitalization.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Hospitalization?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>hospitalization_id:</strong> <?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="hospitalization_id" value="<?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="hospitalization.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
