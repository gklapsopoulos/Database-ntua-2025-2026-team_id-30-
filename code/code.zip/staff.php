<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `staff` ORDER BY `staff_id` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Staff</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_staff.php">Create Staff</a>
        <span class="muted">Showing up to 300 rows from staff</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>staff_id</th>
                    <th>AMKA</th>
                    <th>email</th>
                    <th>hire_date</th>
                    <th>age</th>
                    <th>last_name</th>
                    <th>first_name</th>
                    <th>staff_type</th>
                    <th>media_id</th>
                    <th>working_status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="11">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['staff_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['AMKA'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['email'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['hire_date'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['age'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['last_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['first_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['staff_type'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['media_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['working_status'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_staff.php?staff_id=<?php echo urlencode($row['staff_id']); ?>">Edit</a>
                                <a class="btn danger" href="delete_staff.php?staff_id=<?php echo urlencode($row['staff_id']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
