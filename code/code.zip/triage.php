<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `triage` ORDER BY `triage_id` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Triage</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Triage</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_triage.php">Create Triage</a>
        <span class="muted">Showing up to 300 rows from triage</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>triage_id</th>
                    <th>urgency_level</th>
                    <th>arrival_time</th>
                    <th>service_time</th>
                    <th>AMKA</th>
                    <th>staff_id</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="7">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['triage_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['urgency_level'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['arrival_time'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['service_time'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['AMKA'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['staff_id'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_triage.php?triage_id=<?php echo urlencode($row['triage_id']); ?>">Edit</a>
                                <a class="btn danger" href="delete_triage.php?triage_id=<?php echo urlencode($row['triage_id']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
