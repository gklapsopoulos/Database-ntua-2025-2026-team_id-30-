<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $triage_idValue = "'" . mysqli_real_escape_string($conn, $_POST['triage_id']) . "'";
    $department_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['department_name']) . "'";
    $bed_idValue = "'" . mysqli_real_escape_string($conn, $_POST['bed_id']) . "'";
    $admission_diagnosisValue = "'" . mysqli_real_escape_string($conn, $_POST['admission_diagnosis']) . "'";
    $discharge_diagnosisValue = "'" . mysqli_real_escape_string($conn, $_POST['discharge_diagnosis']) . "'";
    $admission_dateValue = "'" . mysqli_real_escape_string($conn, $_POST['admission_date']) . "'";
    $discharge_dateValue = ($_POST['discharge_date'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['discharge_date']) . "'";
    $current_costValue = "'" . mysqli_real_escape_string($conn, $_POST['current_cost']) . "'";
    $drg_codeValue = "'" . mysqli_real_escape_string($conn, $_POST['drg_code']) . "'";

    $sql = "INSERT INTO `hospitalization` (`triage_id`, `department_name`, `bed_id`, `admission_diagnosis`, `discharge_diagnosis`, `admission_date`, `discharge_date`, `current_cost`, `drg_code`) VALUES ($triage_idValue, $department_nameValue, $bed_idValue, $admission_diagnosisValue, $discharge_diagnosisValue, $admission_dateValue, $discharge_dateValue, $current_costValue, $drg_codeValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: hospitalization.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Hospitalization</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Hospitalization</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>hospitalization_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>triage_id: INT; required; unique value; must already exist in TRIAGE(triage_id)</li>
            <li>department_name: VARCHAR(50); required; must already exist in DEPARTMENT(department_name)</li>
            <li>bed_id: INT; required; must already exist in BEDS(bed_number)</li>
            <li>admission_diagnosis: VARCHAR(250); required; must already exist in DIAGNOSES(diagnosis_code)</li>
            <li>discharge_diagnosis: VARCHAR(250); required; must already exist in DIAGNOSES(diagnosis_code)</li>
            <li>admission_date: DATE; required</li>
            <li>discharge_date: DATE; can be empty/NULL</li>
            <li>current_cost: INT; required</li>
            <li>drg_code: VARCHAR(50); required; must already exist in DRG(drg_code)</li>
            <li>Primary key: hospitalization_id</li>
            <li>Check: discharge_date IS NULL OR admission_date &lt; discharge_date</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                hospitalization_id (auto)
                <input type="number" name="hospitalization_id" disabled>
            </label>

            <label>
                triage_id
                <input type="number" name="triage_id" required>
            </label>

            <label>
                department_name
                <input type="text" name="department_name" required>
            </label>

            <label>
                bed_id
                <input type="number" name="bed_id" required>
            </label>

            <label>
                admission_diagnosis
                <input type="text" name="admission_diagnosis" required>
            </label>

            <label>
                discharge_diagnosis
                <input type="text" name="discharge_diagnosis" required>
            </label>

            <label>
                admission_date
                <input type="date" name="admission_date" required>
            </label>

            <label>
                discharge_date
                <input type="date" name="discharge_date">
            </label>

            <label>
                current_cost
                <input type="number" name="current_cost" required>
            </label>

            <label>
                drg_code
                <input type="text" name="drg_code" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="hospitalization.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
