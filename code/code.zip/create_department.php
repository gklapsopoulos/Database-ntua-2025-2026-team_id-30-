<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $department_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['department_name']) . "'";
    $descriptionValue = "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";
    $floorValue = "'" . mysqli_real_escape_string($conn, $_POST['floor']) . "'";
    $buildingValue = "'" . mysqli_real_escape_string($conn, $_POST['building']) . "'";
    $bed_countValue = "'" . mysqli_real_escape_string($conn, $_POST['bed_count']) . "'";
    $director_idValue = "'" . mysqli_real_escape_string($conn, $_POST['director_id']) . "'";
    $media_idValue = "'" . mysqli_real_escape_string($conn, $_POST['media_id']) . "'";

    $sql = "INSERT INTO `department` (`department_name`, `description`, `floor`, `building`, `bed_count`, `director_id`, `media_id`) VALUES ($department_nameValue, $descriptionValue, $floorValue, $buildingValue, $bed_countValue, $director_idValue, $media_idValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: department.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Department</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Department</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>department_name: VARCHAR(50); primary key; required</li>
            <li>description: VARCHAR(50); required</li>
            <li>floor: INT; required</li>
            <li>building: VARCHAR(25); required</li>
            <li>bed_count: INT; required</li>
            <li>director_id: INT; required; unique value; must already exist in DOCTOR(staff_id)</li>
            <li>media_id: INT; required; must already exist in MEDIA_DEPARTMENT(media_id)</li>
            <li>Primary key: department_name</li>
            <li>Check: bed_count &gt;= 0</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                department_name
                <input type="text" name="department_name" required>
            </label>

            <label>
                description
                <input type="text" name="description" required>
            </label>

            <label>
                floor
                <input type="number" name="floor" required>
            </label>

            <label>
                building
                <input type="text" name="building" required>
            </label>

            <label>
                bed_count
                <input type="number" name="bed_count" required>
            </label>

            <label>
                director_id
                <input type="number" name="director_id" required>
            </label>

            <label>
                media_id
                <input type="number" name="media_id" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="department.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
