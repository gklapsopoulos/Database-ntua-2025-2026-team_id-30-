<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $rankValue = "'" . mysqli_real_escape_string($conn, $_POST['rank']) . "'";
    $descriptionValue = ($_POST['description'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";

    $sql = "INSERT INTO `doctor_ranks` (`rank`, `description`) VALUES ($rankValue, $descriptionValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: doctor_ranks.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Doctor Rank</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Doctor Rank</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>rank: INT; primary key; required</li>
            <li>description: VARCHAR(20); can be empty/NULL</li>
            <li>Primary key: rank</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                rank
                <input type="number" name="rank" required>
            </label>

            <label>
                description
                <input type="text" name="description">
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="doctor_ranks.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
