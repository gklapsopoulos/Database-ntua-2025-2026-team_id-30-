<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $staff_idKey = mysqli_real_escape_string($conn, $_POST['staff_id'] ?? '');
    $department_nameKey = mysqli_real_escape_string($conn, $_POST['department_name'] ?? '');
    $where = "`staff_id` = '$staff_idKey' AND `department_name` = '$department_nameKey'";
    $sql = "DELETE FROM `doctor_department` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: doctor_department.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $staff_idKey = mysqli_real_escape_string($conn, $_GET['staff_id'] ?? '');
    $department_nameKey = mysqli_real_escape_string($conn, $_GET['department_name'] ?? '');
    $where = "`staff_id` = '$staff_idKey' AND `department_name` = '$department_nameKey'";
$result = mysqli_query($conn, "SELECT * FROM `doctor_department` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Doctor Department</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Doctor Department</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="doctor_department.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Doctor Department?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>staff_id:</strong> <?php echo htmlspecialchars($row['staff_id'] ?? ''); ?></li>
                <li><strong>department_name:</strong> <?php echo htmlspecialchars($row['department_name'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>">
                <input type="hidden" name="department_name" value="<?php echo htmlspecialchars($row['department_name'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="doctor_department.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
