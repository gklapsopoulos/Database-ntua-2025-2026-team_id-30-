<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $substance_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['substance_name']) . "'";
    $substance_idKey = mysqli_real_escape_string($conn, $_POST['substance_id'] ?? '');
    $where = "`substance_id` = '$substance_idKey'";

    $sql = "UPDATE `active_substance` SET `substance_name` = $substance_nameValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: active_substance.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $substance_idKey = mysqli_real_escape_string($conn, $_GET['substance_id'] ?? '');
    $where = "`substance_id` = '$substance_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `active_substance` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Active Substance</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Active Substance</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>substance_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>substance_name: VARCHAR(250); required</li>
            <li>Primary key: substance_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="active_substance.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="substance_id" value="<?php echo htmlspecialchars($row['substance_id'] ?? ''); ?>">

            <label>
                substance_id
                <input type="number" name="substance_id" value="<?php echo htmlspecialchars($row['substance_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                substance_name
                <input type="text" name="substance_name" value="<?php echo htmlspecialchars($row['substance_name'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="active_substance.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
