<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $urgency_levelValue = "'" . mysqli_real_escape_string($conn, $_POST['urgency_level']) . "'";
    $arrival_timeValue = "'" . mysqli_real_escape_string($conn, $_POST['arrival_time']) . "'";
    $service_timeValue = ($_POST['service_time'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['service_time']) . "'";
    $AMKAValue = "'" . mysqli_real_escape_string($conn, $_POST['AMKA']) . "'";
    $staff_idValue = "'" . mysqli_real_escape_string($conn, $_POST['staff_id']) . "'";
    $triage_idKey = mysqli_real_escape_string($conn, $_POST['triage_id'] ?? '');
    $where = "`triage_id` = '$triage_idKey'";

    $sql = "UPDATE `triage` SET `urgency_level` = $urgency_levelValue, `arrival_time` = $arrival_timeValue, `service_time` = $service_timeValue, `AMKA` = $AMKAValue, `staff_id` = $staff_idValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: triage.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $triage_idKey = mysqli_real_escape_string($conn, $_GET['triage_id'] ?? '');
    $where = "`triage_id` = '$triage_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `triage` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Triage</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Triage</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>triage_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>urgency_level: INT; required</li>
            <li>arrival_time: DATETIME; required</li>
            <li>service_time: DATETIME; can be empty/NULL</li>
            <li>AMKA: BIGINT; required; must already exist in PATIENTS(AMKA)</li>
            <li>staff_id: INT; required; must already exist in NURSES(staff_id)</li>
            <li>Primary key: triage_id</li>
            <li>Check: urgency_level IN (1, 2, 3, 4, 5)</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="triage.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="triage_id" value="<?php echo htmlspecialchars($row['triage_id'] ?? ''); ?>">

            <label>
                triage_id
                <input type="number" name="triage_id" value="<?php echo htmlspecialchars($row['triage_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                urgency_level
                <select name="urgency_level" required>
                    <option value="1" <?php echo $row['urgency_level'] === '1' ? 'selected' : ''; ?>>1</option>
                    <option value="2" <?php echo $row['urgency_level'] === '2' ? 'selected' : ''; ?>>2</option>
                    <option value="3" <?php echo $row['urgency_level'] === '3' ? 'selected' : ''; ?>>3</option>
                    <option value="4" <?php echo $row['urgency_level'] === '4' ? 'selected' : ''; ?>>4</option>
                    <option value="5" <?php echo $row['urgency_level'] === '5' ? 'selected' : ''; ?>>5</option>
                </select>
            </label>

            <label>
                arrival_time
                <input type="datetime-local" name="arrival_time" value="<?php echo htmlspecialchars($row['arrival_time'] ?? ''); ?>" required>
            </label>

            <label>
                service_time
                <input type="datetime-local" name="service_time" value="<?php echo htmlspecialchars($row['service_time'] ?? ''); ?>">
            </label>

            <label>
                AMKA
                <input type="number" name="AMKA" value="<?php echo htmlspecialchars($row['AMKA'] ?? ''); ?>" required>
            </label>

            <label>
                staff_id
                <input type="number" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="triage.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
