<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $media_idKey = mysqli_real_escape_string($conn, $_POST['media_id'] ?? '');
    $where = "`media_id` = '$media_idKey'";
    $sql = "DELETE FROM `media_staff` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: media_staff.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $media_idKey = mysqli_real_escape_string($conn, $_GET['media_id'] ?? '');
    $where = "`media_id` = '$media_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `media_staff` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Staff Media</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Staff Media</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="media_staff.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Media Staff?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>media_id:</strong> <?php echo htmlspecialchars($row['media_id'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="media_id" value="<?php echo htmlspecialchars($row['media_id'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="media_staff.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
