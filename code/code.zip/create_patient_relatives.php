<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $last_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['last_name']) . "'";
    $first_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['first_name']) . "'";
    $relationshipValue = "'" . mysqli_real_escape_string($conn, $_POST['relationship']) . "'";
    $AMKAValue = "'" . mysqli_real_escape_string($conn, $_POST['AMKA']) . "'";

    $sql = "INSERT INTO `patient_relatives` (`last_name`, `first_name`, `relationship`, `AMKA`) VALUES ($last_nameValue, $first_nameValue, $relationshipValue, $AMKAValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: patient_relatives.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Patient Relative</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Patient Relative</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>relative_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>last_name: VARCHAR(25); required</li>
            <li>first_name: VARCHAR(25); required</li>
            <li>relationship: VARCHAR(25); required</li>
            <li>AMKA: BIGINT; required; must already exist in PATIENTS(AMKA)</li>
            <li>Primary key: relative_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                relative_id (auto)
                <input type="number" name="relative_id" disabled>
            </label>

            <label>
                last_name
                <input type="text" name="last_name" required>
            </label>

            <label>
                first_name
                <input type="text" name="first_name" required>
            </label>

            <label>
                relationship
                <input type="text" name="relationship" required>
            </label>

            <label>
                AMKA
                <input type="number" name="AMKA" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="patient_relatives.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
