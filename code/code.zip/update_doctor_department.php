<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $staff_idKey = mysqli_real_escape_string($conn, $_POST['staff_id'] ?? '');
    $department_nameKey = mysqli_real_escape_string($conn, $_POST['department_name'] ?? '');
    $where = "`staff_id` = '$staff_idKey' AND `department_name` = '$department_nameKey'";

    $sql = "UPDATE `doctor_department` SET  WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: doctor_department.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $staff_idKey = mysqli_real_escape_string($conn, $_GET['staff_id'] ?? '');
    $department_nameKey = mysqli_real_escape_string($conn, $_GET['department_name'] ?? '');
    $where = "`staff_id` = '$staff_idKey' AND `department_name` = '$department_nameKey'";
$result = mysqli_query($conn, "SELECT * FROM `doctor_department` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Doctor Department</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Doctor Department</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>department_name: VARCHAR(50); primary key; required; must already exist in DEPARTMENT(department_name)</li>
            <li>staff_id: INT; primary key; required; must already exist in DOCTOR(staff_id)</li>
            <li>Primary key: staff_id, department_name</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="doctor_department.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>">
                <input type="hidden" name="department_name" value="<?php echo htmlspecialchars($row['department_name'] ?? ''); ?>">

            <label>
                department_name
                <input type="text" name="department_name" value="<?php echo htmlspecialchars($row['department_name'] ?? ''); ?>" required disabled>
            </label>

            <label>
                staff_id
                <input type="number" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>" required disabled>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="doctor_department.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
