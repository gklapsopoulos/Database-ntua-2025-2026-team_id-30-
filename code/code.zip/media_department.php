<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `media_department` ORDER BY `media_id` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Media Department</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Media Department</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_media_department.php">Create Department Media</a>
        <span class="muted">Showing up to 300 rows from media_department</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>media_id</th>
                    <th>description</th>
                    <th>URL</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="4">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['media_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['description'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['URL'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_media_department.php?media_id=<?php echo urlencode($row['media_id']); ?>">Edit</a>
                                <a class="btn danger" href="delete_media_department.php?media_id=<?php echo urlencode($row['media_id']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
