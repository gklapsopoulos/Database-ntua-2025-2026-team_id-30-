<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $test_typeValue = "'" . mysqli_real_escape_string($conn, $_POST['test_type']) . "'";
    $descriptionValue = "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";
    $costValue = "'" . mysqli_real_escape_string($conn, $_POST['cost']) . "'";
    $test_codeKey = mysqli_real_escape_string($conn, $_POST['test_code'] ?? '');
    $where = "`test_code` = '$test_codeKey'";

    $sql = "UPDATE `lab_tests` SET `test_type` = $test_typeValue, `description` = $descriptionValue, `cost` = $costValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: lab_tests.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $test_codeKey = mysqli_real_escape_string($conn, $_GET['test_code'] ?? '');
    $where = "`test_code` = '$test_codeKey'";
$result = mysqli_query($conn, "SELECT * FROM `lab_tests` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Lab Test</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Lab Test</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>test_type: INT; required</li>
            <li>test_code: VARCHAR(250); primary key; required</li>
            <li>description: VARCHAR(250); required</li>
            <li>cost: INT; required</li>
            <li>Primary key: test_code</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="lab_tests.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="test_code" value="<?php echo htmlspecialchars($row['test_code'] ?? ''); ?>">

            <label>
                test_type
                <input type="number" name="test_type" value="<?php echo htmlspecialchars($row['test_type'] ?? ''); ?>" required>
            </label>

            <label>
                test_code
                <input type="text" name="test_code" value="<?php echo htmlspecialchars($row['test_code'] ?? ''); ?>" required disabled>
            </label>

            <label>
                description
                <input type="text" name="description" value="<?php echo htmlspecialchars($row['description'] ?? ''); ?>" required>
            </label>

            <label>
                cost
                <input type="number" name="cost" value="<?php echo htmlspecialchars($row['cost'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="lab_tests.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
