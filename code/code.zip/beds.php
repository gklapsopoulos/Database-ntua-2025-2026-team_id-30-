<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `beds` ORDER BY `bed_number` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beds</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Beds</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_beds.php">Create Bed</a>
        <span class="muted">Showing up to 300 rows from beds</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>bed_number</th>
                    <th>type</th>
                    <th>status</th>
                    <th>department_name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="5">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['bed_number'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['type'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['status'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['department_name'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_beds.php?bed_number=<?php echo urlencode($row['bed_number']); ?>">Edit</a>
                                <a class="btn danger" href="delete_beds.php?bed_number=<?php echo urlencode($row['bed_number']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
