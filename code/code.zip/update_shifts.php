<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $shift_dateValue = "'" . mysqli_real_escape_string($conn, $_POST['shift_date']) . "'";
    $slotValue = "'" . mysqli_real_escape_string($conn, $_POST['slot']) . "'";
    $department_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['department_name']) . "'";
    $shift_statusValue = "'" . mysqli_real_escape_string($conn, $_POST['shift_status']) . "'";
    $shift_idKey = mysqli_real_escape_string($conn, $_POST['shift_id'] ?? '');
    $where = "`shift_id` = '$shift_idKey'";

    $sql = "UPDATE `shifts` SET `shift_date` = $shift_dateValue, `slot` = $slotValue, `department_name` = $department_nameValue, `shift_status` = $shift_statusValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: shifts.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $shift_idKey = mysqli_real_escape_string($conn, $_GET['shift_id'] ?? '');
    $where = "`shift_id` = '$shift_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `shifts` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Shift</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Shift</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>shift_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>shift_date: DATE; required</li>
            <li>slot: VARCHAR(15); required</li>
            <li>department_name: VARCHAR(50); required; must already exist in DEPARTMENT(department_name)</li>
            <li>shift_status: VARCHAR(10); required</li>
            <li>Primary key: shift_id</li>
            <li>Check: slot IN (&#039;morning&#039;, &#039;afternoon&#039;, &#039;night&#039;)</li>
            <li>Check: shift_status IN (&#039;full&#039;, &#039;not full&#039;)</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="shifts.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="shift_id" value="<?php echo htmlspecialchars($row['shift_id'] ?? ''); ?>">

            <label>
                shift_id
                <input type="number" name="shift_id" value="<?php echo htmlspecialchars($row['shift_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                shift_date
                <input type="date" name="shift_date" value="<?php echo htmlspecialchars($row['shift_date'] ?? ''); ?>" required>
            </label>

            <label>
                slot
                <select name="slot" required>
                    <option value="morning" <?php echo $row['slot'] === 'morning' ? 'selected' : ''; ?>>morning</option>
                    <option value="afternoon" <?php echo $row['slot'] === 'afternoon' ? 'selected' : ''; ?>>afternoon</option>
                    <option value="night" <?php echo $row['slot'] === 'night' ? 'selected' : ''; ?>>night</option>
                </select>
            </label>

            <label>
                department_name
                <input type="text" name="department_name" value="<?php echo htmlspecialchars($row['department_name'] ?? ''); ?>" required>
            </label>

            <label>
                shift_status
                <select name="shift_status" required>
                    <option value="full" <?php echo $row['shift_status'] === 'full' ? 'selected' : ''; ?>>full</option>
                    <option value="not full" <?php echo $row['shift_status'] === 'not full' ? 'selected' : ''; ?>>not full</option>
                </select>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="shifts.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
