<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $typeValue = "'" . mysqli_real_escape_string($conn, $_POST['type']) . "'";
    $statusValue = "'" . mysqli_real_escape_string($conn, $_POST['status']) . "'";
    $department_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['department_name']) . "'";
    $bed_numberKey = mysqli_real_escape_string($conn, $_POST['bed_number'] ?? '');
    $where = "`bed_number` = '$bed_numberKey'";

    $sql = "UPDATE `beds` SET `type` = $typeValue, `status` = $statusValue, `department_name` = $department_nameValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: beds.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $bed_numberKey = mysqli_real_escape_string($conn, $_GET['bed_number'] ?? '');
    $where = "`bed_number` = '$bed_numberKey'";
$result = mysqli_query($conn, "SELECT * FROM `beds` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Bed</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Bed</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>bed_number: INT; primary key; required</li>
            <li>type: VARCHAR(25); required</li>
            <li>status: VARCHAR(25); required</li>
            <li>department_name: VARCHAR(50); required; must already exist in DEPARTMENT(department_name)</li>
            <li>Primary key: bed_number</li>
            <li>Check: type IN (&#039;ICU&#039;, &#039;single-bed&#039;, &#039;multi-bed&#039;, &#039;Isolation&#039;, &#039;Recovery-bed&#039;, &#039;Double-room-bed&#039;)</li>
            <li>Check: status IN (&#039;occupied&#039;, &#039;not occupied&#039;, &#039;maintenance&#039;)</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="beds.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="bed_number" value="<?php echo htmlspecialchars($row['bed_number'] ?? ''); ?>">

            <label>
                bed_number
                <input type="number" name="bed_number" value="<?php echo htmlspecialchars($row['bed_number'] ?? ''); ?>" required disabled>
            </label>

            <label>
                type
                <select name="type" required>
                    <option value="ICU" <?php echo $row['type'] === 'ICU' ? 'selected' : ''; ?>>ICU</option>
                    <option value="single-bed" <?php echo $row['type'] === 'single-bed' ? 'selected' : ''; ?>>single-bed</option>
                    <option value="multi-bed" <?php echo $row['type'] === 'multi-bed' ? 'selected' : ''; ?>>multi-bed</option>
                    <option value="Isolation" <?php echo $row['type'] === 'Isolation' ? 'selected' : ''; ?>>Isolation</option>
                    <option value="Recovery-bed" <?php echo $row['type'] === 'Recovery-bed' ? 'selected' : ''; ?>>Recovery-bed</option>
                    <option value="Double-room-bed" <?php echo $row['type'] === 'Double-room-bed' ? 'selected' : ''; ?>>Double-room-bed</option>
                </select>
            </label>

            <label>
                status
                <select name="status" required>
                    <option value="occupied" <?php echo $row['status'] === 'occupied' ? 'selected' : ''; ?>>occupied</option>
                    <option value="not occupied" <?php echo $row['status'] === 'not occupied' ? 'selected' : ''; ?>>not occupied</option>
                    <option value="maintenance" <?php echo $row['status'] === 'maintenance' ? 'selected' : ''; ?>>maintenance</option>
                </select>
            </label>

            <label>
                department_name
                <input type="text" name="department_name" value="<?php echo htmlspecialchars($row['department_name'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="beds.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
