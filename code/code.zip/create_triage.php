<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $urgency_levelValue = "'" . mysqli_real_escape_string($conn, $_POST['urgency_level']) . "'";
    $arrival_timeValue = "'" . mysqli_real_escape_string($conn, $_POST['arrival_time']) . "'";
    $service_timeValue = ($_POST['service_time'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['service_time']) . "'";
    $AMKAValue = "'" . mysqli_real_escape_string($conn, $_POST['AMKA']) . "'";
    $staff_idValue = "'" . mysqli_real_escape_string($conn, $_POST['staff_id']) . "'";

    $sql = "INSERT INTO `triage` (`urgency_level`, `arrival_time`, `service_time`, `AMKA`, `staff_id`) VALUES ($urgency_levelValue, $arrival_timeValue, $service_timeValue, $AMKAValue, $staff_idValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: triage.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Triage</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Triage</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>triage_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>urgency_level: INT; required</li>
            <li>arrival_time: DATETIME; required</li>
            <li>service_time: DATETIME; can be empty/NULL</li>
            <li>AMKA: BIGINT; required; must already exist in PATIENTS(AMKA)</li>
            <li>staff_id: INT; required; must already exist in NURSES(staff_id)</li>
            <li>Primary key: triage_id</li>
            <li>Check: urgency_level IN (1, 2, 3, 4, 5)</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                triage_id (auto)
                <input type="number" name="triage_id" disabled>
            </label>

            <label>
                urgency_level
                <select name="urgency_level" required>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                </select>
            </label>

            <label>
                arrival_time
                <input type="datetime-local" name="arrival_time" required>
            </label>

            <label>
                service_time
                <input type="datetime-local" name="service_time">
            </label>

            <label>
                AMKA
                <input type="number" name="AMKA" required>
            </label>

            <label>
                staff_id
                <input type="number" name="staff_id" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="triage.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
