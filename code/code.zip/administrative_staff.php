<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `administrative_staff` ORDER BY `staff_id` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrative Staff</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Administrative Staff</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_administrative_staff.php">Create Administrative Staff</a>
        <span class="muted">Showing up to 300 rows from administrative_staff</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>role</th>
                    <th>office</th>
                    <th>staff_id</th>
                    <th>department_name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="5">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['role'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['office'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['staff_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['department_name'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_administrative_staff.php?staff_id=<?php echo urlencode($row['staff_id']); ?>">Edit</a>
                                <a class="btn danger" href="delete_administrative_staff.php?staff_id=<?php echo urlencode($row['staff_id']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
