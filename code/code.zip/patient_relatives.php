<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `patient_relatives` ORDER BY `relative_id` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Relatives</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Patient Relatives</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_patient_relatives.php">Create Patient Relative</a>
        <span class="muted">Showing up to 300 rows from patient_relatives</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>relative_id</th>
                    <th>last_name</th>
                    <th>first_name</th>
                    <th>relationship</th>
                    <th>AMKA</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="6">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['relative_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['last_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['first_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['relationship'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['AMKA'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_patient_relatives.php?relative_id=<?php echo urlencode($row['relative_id']); ?>">Edit</a>
                                <a class="btn danger" href="delete_patient_relatives.php?relative_id=<?php echo urlencode($row['relative_id']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
