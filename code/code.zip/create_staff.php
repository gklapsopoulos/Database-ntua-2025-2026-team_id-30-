<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $AMKAValue = "'" . mysqli_real_escape_string($conn, $_POST['AMKA']) . "'";
    $emailValue = "'" . mysqli_real_escape_string($conn, $_POST['email']) . "'";
    $hire_dateValue = "'" . mysqli_real_escape_string($conn, $_POST['hire_date']) . "'";
    $ageValue = "'" . mysqli_real_escape_string($conn, $_POST['age']) . "'";
    $last_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['last_name']) . "'";
    $first_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['first_name']) . "'";
    $staff_typeValue = "'" . mysqli_real_escape_string($conn, $_POST['staff_type']) . "'";
    $media_idValue = "'" . mysqli_real_escape_string($conn, $_POST['media_id']) . "'";
    $working_statusValue = "'" . mysqli_real_escape_string($conn, $_POST['working_status']) . "'";

    $sql = "INSERT INTO `staff` (`AMKA`, `email`, `hire_date`, `age`, `last_name`, `first_name`, `staff_type`, `media_id`, `working_status`) VALUES ($AMKAValue, $emailValue, $hire_dateValue, $ageValue, $last_nameValue, $first_nameValue, $staff_typeValue, $media_idValue, $working_statusValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: staff.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Staff</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Staff</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>staff_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>AMKA: BIGINT; required; unique value</li>
            <li>email: VARCHAR(50); required</li>
            <li>hire_date: DATE; required</li>
            <li>age: INT; required</li>
            <li>last_name: VARCHAR(20); required</li>
            <li>first_name: VARCHAR(20); required</li>
            <li>staff_type: VARCHAR(25); required</li>
            <li>media_id: INT; required; must already exist in MEDIA_STAFF(media_id)</li>
            <li>working_status: BOOLEAN; required</li>
            <li>Primary key: staff_id</li>
            <li>Check: staff_type IN (&#039;doctor&#039;, &#039;nurse&#039;, &#039;administrative staff&#039;)</li>
            <li>Check: age &gt;= 18</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                staff_id (auto)
                <input type="number" name="staff_id" disabled>
            </label>

            <label>
                AMKA
                <input type="number" name="AMKA" required>
            </label>

            <label>
                email
                <input type="email" name="email" required>
            </label>

            <label>
                hire_date
                <input type="date" name="hire_date" required>
            </label>

            <label>
                age
                <input type="number" name="age" required>
            </label>

            <label>
                last_name
                <input type="text" name="last_name" required>
            </label>

            <label>
                first_name
                <input type="text" name="first_name" required>
            </label>

            <label>
                staff_type
                <select name="staff_type" required>
                    <option value="doctor">doctor</option>
                    <option value="nurse">nurse</option>
                    <option value="administrative staff">administrative staff</option>
                </select>
            </label>

            <label>
                media_id
                <input type="number" name="media_id" required>
            </label>

            <label>
                working_status
                <input type="number" name="working_status" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="staff.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
