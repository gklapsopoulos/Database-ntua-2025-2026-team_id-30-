<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $supervisorValue = ($_POST['supervisor'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['supervisor']) . "'";
    $medical_license_numberValue = "'" . mysqli_real_escape_string($conn, $_POST['medical_license_number']) . "'";
    $specialtyValue = "'" . mysqli_real_escape_string($conn, $_POST['specialty']) . "'";
    $rankValue = "'" . mysqli_real_escape_string($conn, $_POST['rank']) . "'";
    $staff_idKey = mysqli_real_escape_string($conn, $_POST['staff_id'] ?? '');
    $where = "`staff_id` = '$staff_idKey'";

    $sql = "UPDATE `doctor` SET `supervisor` = $supervisorValue, `medical_license_number` = $medical_license_numberValue, `specialty` = $specialtyValue, `rank` = $rankValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: doctor.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $staff_idKey = mysqli_real_escape_string($conn, $_GET['staff_id'] ?? '');
    $where = "`staff_id` = '$staff_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `doctor` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Doctor</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Doctor</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>supervisor: INT; can be empty/NULL; must already exist in DOCTOR(staff_id)</li>
            <li>medical_license_number: INT; required; unique value</li>
            <li>specialty: VARCHAR(30); required</li>
            <li>rank: INT; required; must already exist in DOCTOR_RANKS(rank)</li>
            <li>staff_id: INT; primary key; required; must already exist in STAFF(staff_id)</li>
            <li>Primary key: staff_id</li>
            <li>Check: `rank` IN (1, 2, 3, 4)</li>
            <li>Check: specialty IN (&#039;Cardiology&#039;, &#039;Endocrinology&#039;, &#039;Gastroenterology&#039;, &#039;Neurology&#039;, &#039;Psychiatry&#039;, &#039;Neurosurgeon&#039;, &#039;Pediatrician&#039;, &#039;Gynecology&#039;, &#039;Anesthesiology&#039;, &#039;Oncology&#039;, &#039;Dermatology&#039;)</li>
            <li>Check: `rank` != 4 OR supervisor IS NULL</li>
            <li>Check: `rank` != 1 OR supervisor IS NOT NULL</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="doctor.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>">

            <label>
                supervisor
                <input type="number" name="supervisor" value="<?php echo htmlspecialchars($row['supervisor'] ?? ''); ?>">
            </label>

            <label>
                medical_license_number
                <input type="number" name="medical_license_number" value="<?php echo htmlspecialchars($row['medical_license_number'] ?? ''); ?>" required>
            </label>

            <label>
                specialty
                <select name="specialty" required>
                    <option value="Cardiology" <?php echo $row['specialty'] === 'Cardiology' ? 'selected' : ''; ?>>Cardiology</option>
                    <option value="Endocrinology" <?php echo $row['specialty'] === 'Endocrinology' ? 'selected' : ''; ?>>Endocrinology</option>
                    <option value="Gastroenterology" <?php echo $row['specialty'] === 'Gastroenterology' ? 'selected' : ''; ?>>Gastroenterology</option>
                    <option value="Neurology" <?php echo $row['specialty'] === 'Neurology' ? 'selected' : ''; ?>>Neurology</option>
                    <option value="Psychiatry" <?php echo $row['specialty'] === 'Psychiatry' ? 'selected' : ''; ?>>Psychiatry</option>
                    <option value="Neurosurgeon" <?php echo $row['specialty'] === 'Neurosurgeon' ? 'selected' : ''; ?>>Neurosurgeon</option>
                    <option value="Pediatrician" <?php echo $row['specialty'] === 'Pediatrician' ? 'selected' : ''; ?>>Pediatrician</option>
                    <option value="Gynecology" <?php echo $row['specialty'] === 'Gynecology' ? 'selected' : ''; ?>>Gynecology</option>
                    <option value="Anesthesiology" <?php echo $row['specialty'] === 'Anesthesiology' ? 'selected' : ''; ?>>Anesthesiology</option>
                    <option value="Oncology" <?php echo $row['specialty'] === 'Oncology' ? 'selected' : ''; ?>>Oncology</option>
                    <option value="Dermatology" <?php echo $row['specialty'] === 'Dermatology' ? 'selected' : ''; ?>>Dermatology</option>
                </select>
            </label>

            <label>
                rank
                <select name="rank" required>
                    <option value="1" <?php echo $row['rank'] === '1' ? 'selected' : ''; ?>>1</option>
                    <option value="2" <?php echo $row['rank'] === '2' ? 'selected' : ''; ?>>2</option>
                    <option value="3" <?php echo $row['rank'] === '3' ? 'selected' : ''; ?>>3</option>
                    <option value="4" <?php echo $row['rank'] === '4' ? 'selected' : ''; ?>>4</option>
                </select>
            </label>

            <label>
                staff_id
                <input type="number" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>" required disabled>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="doctor.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
