<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $substance_idKey = mysqli_real_escape_string($conn, $_POST['substance_id'] ?? '');
    $AMKAKey = mysqli_real_escape_string($conn, $_POST['AMKA'] ?? '');
    $where = "`substance_id` = '$substance_idKey' AND `AMKA` = '$AMKAKey'";
    $sql = "DELETE FROM `allergic_patients` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: allergic_patients.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $substance_idKey = mysqli_real_escape_string($conn, $_GET['substance_id'] ?? '');
    $AMKAKey = mysqli_real_escape_string($conn, $_GET['AMKA'] ?? '');
    $where = "`substance_id` = '$substance_idKey' AND `AMKA` = '$AMKAKey'";
$result = mysqli_query($conn, "SELECT * FROM `allergic_patients` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Allergic Patient</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Allergic Patient</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="allergic_patients.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Allergic Patients?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>substance_id:</strong> <?php echo htmlspecialchars($row['substance_id'] ?? ''); ?></li>
                <li><strong>AMKA:</strong> <?php echo htmlspecialchars($row['AMKA'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="substance_id" value="<?php echo htmlspecialchars($row['substance_id'] ?? ''); ?>">
                <input type="hidden" name="AMKA" value="<?php echo htmlspecialchars($row['AMKA'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="allergic_patients.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
