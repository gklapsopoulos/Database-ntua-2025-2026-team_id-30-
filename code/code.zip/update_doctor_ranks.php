<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $descriptionValue = ($_POST['description'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";
    $rankKey = mysqli_real_escape_string($conn, $_POST['rank'] ?? '');
    $where = "`rank` = '$rankKey'";

    $sql = "UPDATE `doctor_ranks` SET `description` = $descriptionValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: doctor_ranks.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $rankKey = mysqli_real_escape_string($conn, $_GET['rank'] ?? '');
    $where = "`rank` = '$rankKey'";
$result = mysqli_query($conn, "SELECT * FROM `doctor_ranks` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Doctor Rank</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Doctor Rank</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>rank: INT; primary key; required</li>
            <li>description: VARCHAR(20); can be empty/NULL</li>
            <li>Primary key: rank</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="doctor_ranks.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="rank" value="<?php echo htmlspecialchars($row['rank'] ?? ''); ?>">

            <label>
                rank
                <input type="number" name="rank" value="<?php echo htmlspecialchars($row['rank'] ?? ''); ?>" required disabled>
            </label>

            <label>
                description
                <input type="text" name="description" value="<?php echo htmlspecialchars($row['description'] ?? ''); ?>">
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="doctor_ranks.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
