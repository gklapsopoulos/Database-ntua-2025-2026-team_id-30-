<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `operating_room` ORDER BY `room_id` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Operating Room</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Operating Room</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_operating_room.php">Create Operating Room</a>
        <span class="muted">Showing up to 300 rows from operating_room</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>room_id</th>
                    <th>media_id</th>
                    <th>description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="4">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['room_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['media_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['description'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_operating_room.php?room_id=<?php echo urlencode($row['room_id']); ?>">Edit</a>
                                <a class="btn danger" href="delete_operating_room.php?room_id=<?php echo urlencode($row['room_id']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
