<?php
include 'db_connection.php';
include 'table_helpers.php';
include 'query_definitions.php';

$conn = OpenCon();
$queries = getQueryDefinitions();
$selected = isset($_GET['query']) ? (int)$_GET['query'] : 1;
if (!array_key_exists($selected, $queries)) {
    $selected = 1;
}

$definition = $queries[$selected];
$rows = array();
$columns = array();
$error = '';
$hasRun = isset($_GET['run']);

function getParamValue($param) {
    return $_GET[$param['name']] ?? $param['default'];
}

function valuesForQuery($queryNumber, $definition) {
    $values = array();
    if ($queryNumber === 8) {
        $dept = getParamValue($definition['params'][0]);
        $day = getParamValue($definition['params'][1]);
        return array($dept, $dept, $dept, $day, $dept);
    }
    if ($queryNumber === 12) {
        $weekStart = getParamValue($definition['params'][0]);
        return array($weekStart, $weekStart);
    }
    foreach ($definition['params'] as $param) {
        $values[] = getParamValue($param);
    }
    return $values;
}

if ($hasRun) {
    $stmt = $conn->prepare($definition['sql']);
    if (!$stmt) {
        $error = $conn->error;
    } else {
        $values = valuesForQuery($selected, $definition);
        bindValues($stmt, $values);
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result) {
                while ($field = $result->fetch_field()) {
                    $columns[] = $field->name;
                }
                while ($row = $result->fetch_assoc()) {
                    $rows[] = $row;
                }
            }
        } else {
            $error = $stmt->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Queries</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Queries</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card query-card">
        <form class="query-form" method="GET">
            <label>
                Query
                <select name="query" onchange="this.form.submit()">
                    <?php foreach ($queries as $number => $query): ?>
                        <option value="<?php echo h($number); ?>" <?php echo $number === $selected ? 'selected' : ''; ?>>
                            <?php echo h($query['title']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>

            <?php foreach ($definition['params'] as $param): ?>
                <label>
                    <?php echo h($param['label']); ?>
                    <input type="<?php echo h($param['type']); ?>" name="<?php echo h($param['name']); ?>" value="<?php echo h(getParamValue($param)); ?>" required>
                </label>
            <?php endforeach; ?>

            <div class="form-actions">
                <button type="submit" name="run" value="1">Run Query</button>
            </div>
        </form>
    </div>

    <?php if ($error): ?>
        <p class="error"><?php echo h($error); ?></p>
    <?php endif; ?>

    <?php if ($hasRun && !$error): ?>
        <div class="toolbar">
            <strong><?php echo h($definition['title']); ?></strong>
            <span class="muted"><?php echo count($rows); ?> rows</span>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <?php foreach ($columns as $column): ?>
                            <th><?php echo h($column); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($rows) === 0): ?>
                        <tr><td colspan="<?php echo max(count($columns), 1); ?>">No results found.</td></tr>
                    <?php else: foreach ($rows as $row): ?>
                        <tr>
                            <?php foreach ($columns as $column): ?>
                                <td><?php echo displayValue($row[$column]); ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</main>
</body>
</html>
<?php CloseCon($conn); ?>
