<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `hospitalization_procedure` ORDER BY `procedure_hospitalization_id` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospitalization Procedure</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Hospitalization Procedure</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_hospitalization_procedure.php">Create Hospitalization Procedure</a>
        <span class="muted">Showing up to 300 rows from hospitalization_procedure</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>procedure_hospitalization_id</th>
                    <th>procedure_start_time</th>
                    <th>procedure_end_time</th>
                    <th>procedure_duration</th>
                    <th>procedure_code</th>
                    <th>hospitalization_id</th>
                    <th>room_id</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="8">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['procedure_hospitalization_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['procedure_start_time'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['procedure_end_time'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['procedure_duration'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['procedure_code'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['room_id'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_hospitalization_procedure.php?procedure_hospitalization_id=<?php echo urlencode($row['procedure_hospitalization_id']); ?>">Edit</a>
                                <a class="btn danger" href="delete_hospitalization_procedure.php?procedure_hospitalization_id=<?php echo urlencode($row['procedure_hospitalization_id']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
