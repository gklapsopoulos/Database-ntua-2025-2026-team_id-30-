<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $medication_idKey = mysqli_real_escape_string($conn, $_POST['medication_id'] ?? '');
    $substance_idKey = mysqli_real_escape_string($conn, $_POST['substance_id'] ?? '');
    $where = "`medication_id` = '$medication_idKey' AND `substance_id` = '$substance_idKey'";

    $sql = "UPDATE `medication_substance` SET  WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: medication_substance.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $medication_idKey = mysqli_real_escape_string($conn, $_GET['medication_id'] ?? '');
    $substance_idKey = mysqli_real_escape_string($conn, $_GET['substance_id'] ?? '');
    $where = "`medication_id` = '$medication_idKey' AND `substance_id` = '$substance_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `medication_substance` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Medication Substance</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Medication Substance</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>medication_id: INT; primary key; required; must already exist in MEDICATION(medication_id)</li>
            <li>substance_id: INT; primary key; required; must already exist in ACTIVE_SUBSTANCE(substance_id)</li>
            <li>Primary key: medication_id, substance_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="medication_substance.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="medication_id" value="<?php echo htmlspecialchars($row['medication_id'] ?? ''); ?>">
                <input type="hidden" name="substance_id" value="<?php echo htmlspecialchars($row['substance_id'] ?? ''); ?>">

            <label>
                medication_id
                <input type="number" name="medication_id" value="<?php echo htmlspecialchars($row['medication_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                substance_id
                <input type="number" name="substance_id" value="<?php echo htmlspecialchars($row['substance_id'] ?? ''); ?>" required disabled>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="medication_substance.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
