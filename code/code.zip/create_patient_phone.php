<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $phoneValue = "'" . mysqli_real_escape_string($conn, $_POST['phone']) . "'";
    $AMKAValue = "'" . mysqli_real_escape_string($conn, $_POST['AMKA']) . "'";

    $sql = "INSERT INTO `patient_phone` (`phone`, `AMKA`) VALUES ($phoneValue, $AMKAValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: patient_phone.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Patient Phone</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Patient Phone</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>phone: VARCHAR(20); primary key; required</li>
            <li>AMKA: BIGINT; primary key; required; must already exist in PATIENTS(AMKA)</li>
            <li>Primary key: phone, AMKA</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                phone
                <input type="text" name="phone" required>
            </label>

            <label>
                AMKA
                <input type="number" name="AMKA" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="patient_phone.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
