<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $substance_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['substance_name']) . "'";

    $sql = "INSERT INTO `active_substance` (`substance_name`) VALUES ($substance_nameValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: active_substance.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Active Substance</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Active Substance</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>substance_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>substance_name: VARCHAR(250); required</li>
            <li>Primary key: substance_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                substance_id (auto)
                <input type="number" name="substance_id" disabled>
            </label>

            <label>
                substance_name
                <input type="text" name="substance_name" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="active_substance.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
