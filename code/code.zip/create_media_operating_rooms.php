<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $descriptionValue = ($_POST['description'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";
    $URLValue = "'" . mysqli_real_escape_string($conn, $_POST['URL']) . "'";

    $sql = "INSERT INTO `media_operating_rooms` (`description`, `URL`) VALUES ($descriptionValue, $URLValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: media_operating_rooms.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Operating Room Media</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Operating Room Media</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>media_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>description: VARCHAR(100); can be empty/NULL</li>
            <li>URL: VARCHAR(255); required</li>
            <li>Primary key: media_id</li>
            <li>Unique: URL</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                media_id (auto)
                <input type="number" name="media_id" disabled>
            </label>

            <label>
                description
                <input type="text" name="description">
            </label>

            <label>
                URL
                <input type="text" name="URL" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="media_operating_rooms.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
