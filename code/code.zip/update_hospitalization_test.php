<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $test_dateValue = "'" . mysqli_real_escape_string($conn, $_POST['test_date']) . "'";
    $resultValue = "'" . mysqli_real_escape_string($conn, $_POST['result']) . "'";
    $test_codeValue = "'" . mysqli_real_escape_string($conn, $_POST['test_code']) . "'";
    $hospitalization_idValue = "'" . mysqli_real_escape_string($conn, $_POST['hospitalization_id']) . "'";
    $staff_idValue = "'" . mysqli_real_escape_string($conn, $_POST['staff_id']) . "'";
    $test_idKey = mysqli_real_escape_string($conn, $_POST['test_id'] ?? '');
    $where = "`test_id` = '$test_idKey'";

    $sql = "UPDATE `hospitalization_test` SET `test_date` = $test_dateValue, `result` = $resultValue, `test_code` = $test_codeValue, `hospitalization_id` = $hospitalization_idValue, `staff_id` = $staff_idValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: hospitalization_test.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $test_idKey = mysqli_real_escape_string($conn, $_GET['test_id'] ?? '');
    $where = "`test_id` = '$test_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `hospitalization_test` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Hospitalization Test</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Hospitalization Test</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>test_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>test_date: DATE; required</li>
            <li>result: VARCHAR(100); required</li>
            <li>test_code: VARCHAR(250); required; must already exist in LAB_TESTS(test_code)</li>
            <li>hospitalization_id: INT; required; must already exist in HOSPITALIZATION(hospitalization_id)</li>
            <li>staff_id: INT; required; must already exist in DOCTOR(staff_id)</li>
            <li>Primary key: test_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="hospitalization_test.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="test_id" value="<?php echo htmlspecialchars($row['test_id'] ?? ''); ?>">

            <label>
                test_id
                <input type="number" name="test_id" value="<?php echo htmlspecialchars($row['test_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                test_date
                <input type="date" name="test_date" value="<?php echo htmlspecialchars($row['test_date'] ?? ''); ?>" required>
            </label>

            <label>
                result
                <input type="text" name="result" value="<?php echo htmlspecialchars($row['result'] ?? ''); ?>" required>
            </label>

            <label>
                test_code
                <input type="text" name="test_code" value="<?php echo htmlspecialchars($row['test_code'] ?? ''); ?>" required>
            </label>

            <label>
                hospitalization_id
                <input type="number" name="hospitalization_id" value="<?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?>" required>
            </label>

            <label>
                staff_id
                <input type="number" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="hospitalization_test.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
