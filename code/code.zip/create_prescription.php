<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $prescription_start_dateValue = "'" . mysqli_real_escape_string($conn, $_POST['prescription_start_date']) . "'";
    $prescription_end_dateValue = "'" . mysqli_real_escape_string($conn, $_POST['prescription_end_date']) . "'";
    $dosageValue = "'" . mysqli_real_escape_string($conn, $_POST['dosage']) . "'";
    $frequencyValue = "'" . mysqli_real_escape_string($conn, $_POST['frequency']) . "'";
    $medication_idValue = "'" . mysqli_real_escape_string($conn, $_POST['medication_id']) . "'";
    $staff_idValue = "'" . mysqli_real_escape_string($conn, $_POST['staff_id']) . "'";
    $AMKAValue = "'" . mysqli_real_escape_string($conn, $_POST['AMKA']) . "'";
    $hospitalization_idValue = "'" . mysqli_real_escape_string($conn, $_POST['hospitalization_id']) . "'";

    $sql = "INSERT INTO `prescription` (`prescription_start_date`, `prescription_end_date`, `dosage`, `frequency`, `medication_id`, `staff_id`, `AMKA`, `hospitalization_id`) VALUES ($prescription_start_dateValue, $prescription_end_dateValue, $dosageValue, $frequencyValue, $medication_idValue, $staff_idValue, $AMKAValue, $hospitalization_idValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: prescription.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Prescription</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Prescription</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>prescription_start_date: DATE; primary key; required</li>
            <li>prescription_end_date: DATE; required</li>
            <li>dosage: VARCHAR(50); required</li>
            <li>frequency: VARCHAR(50); required</li>
            <li>medication_id: INT; primary key; required; must already exist in MEDICATION(medication_id)</li>
            <li>staff_id: INT; primary key; required; must already exist in DOCTOR(staff_id)</li>
            <li>AMKA: BIGINT; primary key; required; must already exist in PATIENTS(AMKA)</li>
            <li>hospitalization_id: INT; required; must already exist in HOSPITALIZATION(hospitalization_id)</li>
            <li>Primary key: medication_id, prescription_start_date, staff_id, AMKA</li>
            <li>Check: prescription_start_date &lt;= prescription_end_date</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                prescription_start_date
                <input type="date" name="prescription_start_date" required>
            </label>

            <label>
                prescription_end_date
                <input type="date" name="prescription_end_date" required>
            </label>

            <label>
                dosage
                <input type="text" name="dosage" required>
            </label>

            <label>
                frequency
                <input type="text" name="frequency" required>
            </label>

            <label>
                medication_id
                <input type="number" name="medication_id" required>
            </label>

            <label>
                staff_id
                <input type="number" name="staff_id" required>
            </label>

            <label>
                AMKA
                <input type="number" name="AMKA" required>
            </label>

            <label>
                hospitalization_id
                <input type="number" name="hospitalization_id" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="prescription.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
