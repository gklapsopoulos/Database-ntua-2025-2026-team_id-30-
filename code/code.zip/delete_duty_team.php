<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $staff_idKey = mysqli_real_escape_string($conn, $_POST['staff_id'] ?? '');
    $shift_idKey = mysqli_real_escape_string($conn, $_POST['shift_id'] ?? '');
    $where = "`staff_id` = '$staff_idKey' AND `shift_id` = '$shift_idKey'";
    $sql = "DELETE FROM `duty_team` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: duty_team.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $staff_idKey = mysqli_real_escape_string($conn, $_GET['staff_id'] ?? '');
    $shift_idKey = mysqli_real_escape_string($conn, $_GET['shift_id'] ?? '');
    $where = "`staff_id` = '$staff_idKey' AND `shift_id` = '$shift_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `duty_team` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Duty Team</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Duty Team</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="duty_team.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Duty Team?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>staff_id:</strong> <?php echo htmlspecialchars($row['staff_id'] ?? ''); ?></li>
                <li><strong>shift_id:</strong> <?php echo htmlspecialchars($row['shift_id'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>">
                <input type="hidden" name="shift_id" value="<?php echo htmlspecialchars($row['shift_id'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="duty_team.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
