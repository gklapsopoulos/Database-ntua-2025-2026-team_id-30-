<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $diagnosis_codeValue = "'" . mysqli_real_escape_string($conn, $_POST['diagnosis_code']) . "'";
    $descriptionValue = "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";

    $sql = "INSERT INTO `diagnoses` (`diagnosis_code`, `description`) VALUES ($diagnosis_codeValue, $descriptionValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: diagnoses.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Diagnosis</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Diagnosis</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>diagnosis_code: VARCHAR(250); primary key; required</li>
            <li>description: VARCHAR(250); required</li>
            <li>Primary key: diagnosis_code</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                diagnosis_code
                <input type="text" name="diagnosis_code" required>
            </label>

            <label>
                description
                <input type="text" name="description" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="diagnoses.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
