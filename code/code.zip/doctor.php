<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `doctor` ORDER BY `staff_id` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Doctor</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_doctor.php">Create Doctor</a>
        <span class="muted">Showing up to 300 rows from doctor</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>supervisor</th>
                    <th>medical_license_number</th>
                    <th>specialty</th>
                    <th>rank</th>
                    <th>staff_id</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="6">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['supervisor'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['medical_license_number'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['specialty'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['rank'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['staff_id'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_doctor.php?staff_id=<?php echo urlencode($row['staff_id']); ?>">Edit</a>
                                <a class="btn danger" href="delete_doctor.php?staff_id=<?php echo urlencode($row['staff_id']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
