<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $descriptionValue = "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";
    $diagnosis_codeKey = mysqli_real_escape_string($conn, $_POST['diagnosis_code'] ?? '');
    $where = "`diagnosis_code` = '$diagnosis_codeKey'";

    $sql = "UPDATE `diagnoses` SET `description` = $descriptionValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: diagnoses.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $diagnosis_codeKey = mysqli_real_escape_string($conn, $_GET['diagnosis_code'] ?? '');
    $where = "`diagnosis_code` = '$diagnosis_codeKey'";
$result = mysqli_query($conn, "SELECT * FROM `diagnoses` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Diagnosis</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Diagnosis</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>diagnosis_code: VARCHAR(250); primary key; required</li>
            <li>description: VARCHAR(250); required</li>
            <li>Primary key: diagnosis_code</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="diagnoses.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="diagnosis_code" value="<?php echo htmlspecialchars($row['diagnosis_code'] ?? ''); ?>">

            <label>
                diagnosis_code
                <input type="text" name="diagnosis_code" value="<?php echo htmlspecialchars($row['diagnosis_code'] ?? ''); ?>" required disabled>
            </label>

            <label>
                description
                <input type="text" name="description" value="<?php echo htmlspecialchars($row['description'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="diagnoses.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
