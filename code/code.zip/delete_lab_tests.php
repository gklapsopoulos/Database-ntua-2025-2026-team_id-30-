<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $test_codeKey = mysqli_real_escape_string($conn, $_POST['test_code'] ?? '');
    $where = "`test_code` = '$test_codeKey'";
    $sql = "DELETE FROM `lab_tests` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: lab_tests.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $test_codeKey = mysqli_real_escape_string($conn, $_GET['test_code'] ?? '');
    $where = "`test_code` = '$test_codeKey'";
$result = mysqli_query($conn, "SELECT * FROM `lab_tests` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Lab Test</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Lab Test</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="lab_tests.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Lab Tests?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>test_code:</strong> <?php echo htmlspecialchars($row['test_code'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="test_code" value="<?php echo htmlspecialchars($row['test_code'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="lab_tests.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
