<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $supervisorValue = ($_POST['supervisor'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['supervisor']) . "'";
    $medical_license_numberValue = "'" . mysqli_real_escape_string($conn, $_POST['medical_license_number']) . "'";
    $specialtyValue = "'" . mysqli_real_escape_string($conn, $_POST['specialty']) . "'";
    $rankValue = "'" . mysqli_real_escape_string($conn, $_POST['rank']) . "'";
    $staff_idValue = "'" . mysqli_real_escape_string($conn, $_POST['staff_id']) . "'";

    $sql = "INSERT INTO `doctor` (`supervisor`, `medical_license_number`, `specialty`, `rank`, `staff_id`) VALUES ($supervisorValue, $medical_license_numberValue, $specialtyValue, $rankValue, $staff_idValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: doctor.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Doctor</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Doctor</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>supervisor: INT; can be empty/NULL; must already exist in DOCTOR(staff_id)</li>
            <li>medical_license_number: INT; required; unique value</li>
            <li>specialty: VARCHAR(30); required</li>
            <li>rank: INT; required; must already exist in DOCTOR_RANKS(rank)</li>
            <li>staff_id: INT; primary key; required; must already exist in STAFF(staff_id)</li>
            <li>Primary key: staff_id</li>
            <li>Check: `rank` IN (1, 2, 3, 4)</li>
            <li>Check: specialty IN (&#039;Cardiology&#039;, &#039;Endocrinology&#039;, &#039;Gastroenterology&#039;, &#039;Neurology&#039;, &#039;Psychiatry&#039;, &#039;Neurosurgeon&#039;, &#039;Pediatrician&#039;, &#039;Gynecology&#039;, &#039;Anesthesiology&#039;, &#039;Oncology&#039;, &#039;Dermatology&#039;)</li>
            <li>Check: `rank` != 4 OR supervisor IS NULL</li>
            <li>Check: `rank` != 1 OR supervisor IS NOT NULL</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                supervisor
                <input type="number" name="supervisor">
            </label>

            <label>
                medical_license_number
                <input type="number" name="medical_license_number" required>
            </label>

            <label>
                specialty
                <select name="specialty" required>
                    <option value="Cardiology">Cardiology</option>
                    <option value="Endocrinology">Endocrinology</option>
                    <option value="Gastroenterology">Gastroenterology</option>
                    <option value="Neurology">Neurology</option>
                    <option value="Psychiatry">Psychiatry</option>
                    <option value="Neurosurgeon">Neurosurgeon</option>
                    <option value="Pediatrician">Pediatrician</option>
                    <option value="Gynecology">Gynecology</option>
                    <option value="Anesthesiology">Anesthesiology</option>
                    <option value="Oncology">Oncology</option>
                    <option value="Dermatology">Dermatology</option>
                </select>
            </label>

            <label>
                rank
                <select name="rank" required>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                </select>
            </label>

            <label>
                staff_id
                <input type="number" name="staff_id" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="doctor.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
