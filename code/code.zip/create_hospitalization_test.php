<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $test_dateValue = "'" . mysqli_real_escape_string($conn, $_POST['test_date']) . "'";
    $resultValue = "'" . mysqli_real_escape_string($conn, $_POST['result']) . "'";
    $test_codeValue = "'" . mysqli_real_escape_string($conn, $_POST['test_code']) . "'";
    $hospitalization_idValue = "'" . mysqli_real_escape_string($conn, $_POST['hospitalization_id']) . "'";
    $staff_idValue = "'" . mysqli_real_escape_string($conn, $_POST['staff_id']) . "'";

    $sql = "INSERT INTO `hospitalization_test` (`test_date`, `result`, `test_code`, `hospitalization_id`, `staff_id`) VALUES ($test_dateValue, $resultValue, $test_codeValue, $hospitalization_idValue, $staff_idValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: hospitalization_test.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Hospitalization Test</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Hospitalization Test</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>test_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>test_date: DATE; required</li>
            <li>result: VARCHAR(100); required</li>
            <li>test_code: VARCHAR(250); required; must already exist in LAB_TESTS(test_code)</li>
            <li>hospitalization_id: INT; required; must already exist in HOSPITALIZATION(hospitalization_id)</li>
            <li>staff_id: INT; required; must already exist in DOCTOR(staff_id)</li>
            <li>Primary key: test_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                test_id (auto)
                <input type="number" name="test_id" disabled>
            </label>

            <label>
                test_date
                <input type="date" name="test_date" required>
            </label>

            <label>
                result
                <input type="text" name="result" required>
            </label>

            <label>
                test_code
                <input type="text" name="test_code" required>
            </label>

            <label>
                hospitalization_id
                <input type="number" name="hospitalization_id" required>
            </label>

            <label>
                staff_id
                <input type="number" name="staff_id" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="hospitalization_test.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
