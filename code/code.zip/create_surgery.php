<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $surgeon_idValue = "'" . mysqli_real_escape_string($conn, $_POST['surgeon_id']) . "'";
    $surgery_idValue = "'" . mysqli_real_escape_string($conn, $_POST['surgery_id']) . "'";

    $sql = "INSERT INTO `surgery` (`surgeon_id`, `surgery_id`) VALUES ($surgeon_idValue, $surgery_idValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: surgery.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Surgery</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Surgery</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>surgeon_id: INT; required; must already exist in DOCTOR(staff_id)</li>
            <li>surgery_id: INT; primary key; required; must already exist in HOSPITALIZATION_PROCEDURE(procedure_hospitalization_id)</li>
            <li>Primary key: surgery_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                surgeon_id
                <input type="number" name="surgeon_id" required>
            </label>

            <label>
                surgery_id
                <input type="number" name="surgery_id" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="surgery.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
