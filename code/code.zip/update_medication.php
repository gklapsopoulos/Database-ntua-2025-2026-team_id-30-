<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $product_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['product_name']) . "'";
    $route_of_administrationValue = ($_POST['route_of_administration'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['route_of_administration']) . "'";
    $product_authorisation_countryValue = ($_POST['product_authorisation_country'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['product_authorisation_country']) . "'";
    $marketing_authorisation_holderValue = ($_POST['marketing_authorisation_holder'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['marketing_authorisation_holder']) . "'";
    $pharmacovigilance_system_master_file_locationValue = ($_POST['pharmacovigilance_system_master_file_location'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['pharmacovigilance_system_master_file_location']) . "'";
    $pharmacovigilance_emailValue = ($_POST['pharmacovigilance_email'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['pharmacovigilance_email']) . "'";
    $pharmacovigilance_phoneValue = ($_POST['pharmacovigilance_phone'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['pharmacovigilance_phone']) . "'";
    $medication_idKey = mysqli_real_escape_string($conn, $_POST['medication_id'] ?? '');
    $where = "`medication_id` = '$medication_idKey'";

    $sql = "UPDATE `medication` SET `product_name` = $product_nameValue, `route_of_administration` = $route_of_administrationValue, `product_authorisation_country` = $product_authorisation_countryValue, `marketing_authorisation_holder` = $marketing_authorisation_holderValue, `pharmacovigilance_system_master_file_location` = $pharmacovigilance_system_master_file_locationValue, `pharmacovigilance_email` = $pharmacovigilance_emailValue, `pharmacovigilance_phone` = $pharmacovigilance_phoneValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: medication.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $medication_idKey = mysqli_real_escape_string($conn, $_GET['medication_id'] ?? '');
    $where = "`medication_id` = '$medication_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `medication` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Medication</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Medication</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>medication_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>product_name: VARCHAR(300); required</li>
            <li>route_of_administration: VARCHAR(250); can be empty/NULL</li>
            <li>product_authorisation_country: VARCHAR(50); can be empty/NULL</li>
            <li>marketing_authorisation_holder: VARCHAR(250); can be empty/NULL</li>
            <li>pharmacovigilance_system_master_file_location: VARCHAR(250); can be empty/NULL</li>
            <li>pharmacovigilance_email: VARCHAR(50); can be empty/NULL</li>
            <li>pharmacovigilance_phone: VARCHAR(50); can be empty/NULL</li>
            <li>Primary key: medication_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="medication.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="medication_id" value="<?php echo htmlspecialchars($row['medication_id'] ?? ''); ?>">

            <label>
                medication_id
                <input type="number" name="medication_id" value="<?php echo htmlspecialchars($row['medication_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                product_name
                <input type="text" name="product_name" value="<?php echo htmlspecialchars($row['product_name'] ?? ''); ?>" required>
            </label>

            <label>
                route_of_administration
                <input type="text" name="route_of_administration" value="<?php echo htmlspecialchars($row['route_of_administration'] ?? ''); ?>">
            </label>

            <label>
                product_authorisation_country
                <input type="text" name="product_authorisation_country" value="<?php echo htmlspecialchars($row['product_authorisation_country'] ?? ''); ?>">
            </label>

            <label>
                marketing_authorisation_holder
                <input type="text" name="marketing_authorisation_holder" value="<?php echo htmlspecialchars($row['marketing_authorisation_holder'] ?? ''); ?>">
            </label>

            <label>
                pharmacovigilance_system_master_file_location
                <input type="text" name="pharmacovigilance_system_master_file_location" value="<?php echo htmlspecialchars($row['pharmacovigilance_system_master_file_location'] ?? ''); ?>">
            </label>

            <label>
                pharmacovigilance_email
                <input type="email" name="pharmacovigilance_email" value="<?php echo htmlspecialchars($row['pharmacovigilance_email'] ?? ''); ?>">
            </label>

            <label>
                pharmacovigilance_phone
                <input type="text" name="pharmacovigilance_phone" value="<?php echo htmlspecialchars($row['pharmacovigilance_phone'] ?? ''); ?>">
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="medication.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
