<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $phoneKey = mysqli_real_escape_string($conn, $_POST['phone'] ?? '');
    $AMKAKey = mysqli_real_escape_string($conn, $_POST['AMKA'] ?? '');
    $where = "`phone` = '$phoneKey' AND `AMKA` = '$AMKAKey'";

    $sql = "UPDATE `patient_phone` SET  WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: patient_phone.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $phoneKey = mysqli_real_escape_string($conn, $_GET['phone'] ?? '');
    $AMKAKey = mysqli_real_escape_string($conn, $_GET['AMKA'] ?? '');
    $where = "`phone` = '$phoneKey' AND `AMKA` = '$AMKAKey'";
$result = mysqli_query($conn, "SELECT * FROM `patient_phone` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Patient Phone</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Patient Phone</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>phone: VARCHAR(20); primary key; required</li>
            <li>AMKA: BIGINT; primary key; required; must already exist in PATIENTS(AMKA)</li>
            <li>Primary key: phone, AMKA</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="patient_phone.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="phone" value="<?php echo htmlspecialchars($row['phone'] ?? ''); ?>">
                <input type="hidden" name="AMKA" value="<?php echo htmlspecialchars($row['AMKA'] ?? ''); ?>">

            <label>
                phone
                <input type="text" name="phone" value="<?php echo htmlspecialchars($row['phone'] ?? ''); ?>" required disabled>
            </label>

            <label>
                AMKA
                <input type="number" name="AMKA" value="<?php echo htmlspecialchars($row['AMKA'] ?? ''); ?>" required disabled>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="patient_phone.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
