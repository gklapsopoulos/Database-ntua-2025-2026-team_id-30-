<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `patient_phone` ORDER BY `phone`, `AMKA` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Phone</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Patient Phone</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_patient_phone.php">Create Patient Phone</a>
        <span class="muted">Showing up to 300 rows from patient_phone</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>phone</th>
                    <th>AMKA</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="3">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['phone'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['AMKA'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_patient_phone.php?phone=<?php echo urlencode($row['phone']); ?>&AMKA=<?php echo urlencode($row['AMKA']); ?>">Edit</a>
                                <a class="btn danger" href="delete_patient_phone.php?phone=<?php echo urlencode($row['phone']); ?>&AMKA=<?php echo urlencode($row['AMKA']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
