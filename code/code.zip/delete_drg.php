<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $drg_codeKey = mysqli_real_escape_string($conn, $_POST['drg_code'] ?? '');
    $where = "`drg_code` = '$drg_codeKey'";
    $sql = "DELETE FROM `drg` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: drg.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $drg_codeKey = mysqli_real_escape_string($conn, $_GET['drg_code'] ?? '');
    $where = "`drg_code` = '$drg_codeKey'";
$result = mysqli_query($conn, "SELECT * FROM `drg` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Drg</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Drg</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="drg.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Drg?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>drg_code:</strong> <?php echo htmlspecialchars($row['drg_code'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="drg_code" value="<?php echo htmlspecialchars($row['drg_code'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="drg.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
