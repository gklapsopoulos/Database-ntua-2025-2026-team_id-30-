<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $procedure_codeValue = "'" . mysqli_real_escape_string($conn, $_POST['procedure_code']) . "'";
    $descriptionValue = "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";
    $categoryValue = "'" . mysqli_real_escape_string($conn, $_POST['category']) . "'";
    $costValue = "'" . mysqli_real_escape_string($conn, $_POST['cost']) . "'";

    $sql = "INSERT INTO `medical_procedures` (`procedure_code`, `description`, `category`, `cost`) VALUES ($procedure_codeValue, $descriptionValue, $categoryValue, $costValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: medical_procedures.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Medical Procedure</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Medical Procedure</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>procedure_code: VARCHAR(250); primary key; required</li>
            <li>description: VARCHAR(400); required</li>
            <li>category: VARCHAR(150); required</li>
            <li>cost: INT; required</li>
            <li>Primary key: procedure_code</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                procedure_code
                <input type="text" name="procedure_code" required>
            </label>

            <label>
                description
                <input type="text" name="description" required>
            </label>

            <label>
                category
                <input type="text" name="category" required>
            </label>

            <label>
                cost
                <input type="number" name="cost" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="medical_procedures.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
