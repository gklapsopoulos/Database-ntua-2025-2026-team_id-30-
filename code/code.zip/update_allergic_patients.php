<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $substance_idKey = mysqli_real_escape_string($conn, $_POST['substance_id'] ?? '');
    $AMKAKey = mysqli_real_escape_string($conn, $_POST['AMKA'] ?? '');
    $where = "`substance_id` = '$substance_idKey' AND `AMKA` = '$AMKAKey'";

    $sql = "UPDATE `allergic_patients` SET  WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: allergic_patients.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $substance_idKey = mysqli_real_escape_string($conn, $_GET['substance_id'] ?? '');
    $AMKAKey = mysqli_real_escape_string($conn, $_GET['AMKA'] ?? '');
    $where = "`substance_id` = '$substance_idKey' AND `AMKA` = '$AMKAKey'";
$result = mysqli_query($conn, "SELECT * FROM `allergic_patients` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Allergic Patient</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Allergic Patient</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>substance_id: INT; primary key; required; must already exist in ACTIVE_SUBSTANCE(substance_id)</li>
            <li>AMKA: BIGINT; primary key; required; must already exist in PATIENTS(AMKA)</li>
            <li>Primary key: substance_id, AMKA</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="allergic_patients.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="substance_id" value="<?php echo htmlspecialchars($row['substance_id'] ?? ''); ?>">
                <input type="hidden" name="AMKA" value="<?php echo htmlspecialchars($row['AMKA'] ?? ''); ?>">

            <label>
                substance_id
                <input type="number" name="substance_id" value="<?php echo htmlspecialchars($row['substance_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                AMKA
                <input type="number" name="AMKA" value="<?php echo htmlspecialchars($row['AMKA'] ?? ''); ?>" required disabled>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="allergic_patients.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
