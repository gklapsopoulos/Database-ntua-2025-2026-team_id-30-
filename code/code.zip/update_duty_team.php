<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $staff_idKey = mysqli_real_escape_string($conn, $_POST['staff_id'] ?? '');
    $shift_idKey = mysqli_real_escape_string($conn, $_POST['shift_id'] ?? '');
    $where = "`staff_id` = '$staff_idKey' AND `shift_id` = '$shift_idKey'";

    $sql = "UPDATE `duty_team` SET  WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: duty_team.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $staff_idKey = mysqli_real_escape_string($conn, $_GET['staff_id'] ?? '');
    $shift_idKey = mysqli_real_escape_string($conn, $_GET['shift_id'] ?? '');
    $where = "`staff_id` = '$staff_idKey' AND `shift_id` = '$shift_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `duty_team` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Duty Team</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Duty Team</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>staff_id: INT; primary key; required; must already exist in STAFF(staff_id)</li>
            <li>shift_id: INT; primary key; required; must already exist in SHIFTS(shift_id)</li>
            <li>Primary key: staff_id, shift_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="duty_team.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>">
                <input type="hidden" name="shift_id" value="<?php echo htmlspecialchars($row['shift_id'] ?? ''); ?>">

            <label>
                staff_id
                <input type="number" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                shift_id
                <input type="number" name="shift_id" value="<?php echo htmlspecialchars($row['shift_id'] ?? ''); ?>" required disabled>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="duty_team.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
