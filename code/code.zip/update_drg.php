<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $descriptionValue = "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";
    $costValue = "'" . mysqli_real_escape_string($conn, $_POST['cost']) . "'";
    $average_length_of_stayValue = "'" . mysqli_real_escape_string($conn, $_POST['average_length_of_stay']) . "'";
    $drg_codeKey = mysqli_real_escape_string($conn, $_POST['drg_code'] ?? '');
    $where = "`drg_code` = '$drg_codeKey'";

    $sql = "UPDATE `drg` SET `description` = $descriptionValue, `cost` = $costValue, `average_length_of_stay` = $average_length_of_stayValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: drg.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $drg_codeKey = mysqli_real_escape_string($conn, $_GET['drg_code'] ?? '');
    $where = "`drg_code` = '$drg_codeKey'";
$result = mysqli_query($conn, "SELECT * FROM `drg` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Drg</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Drg</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>drg_code: VARCHAR(50); primary key; required</li>
            <li>description: VARCHAR(255); required</li>
            <li>cost: INT; required</li>
            <li>average_length_of_stay: INT; required</li>
            <li>Primary key: drg_code</li>
            <li>Check: cost &gt;= 0</li>
            <li>Check: average_length_of_stay &gt;= 0</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="drg.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="drg_code" value="<?php echo htmlspecialchars($row['drg_code'] ?? ''); ?>">

            <label>
                drg_code
                <input type="text" name="drg_code" value="<?php echo htmlspecialchars($row['drg_code'] ?? ''); ?>" required disabled>
            </label>

            <label>
                description
                <input type="text" name="description" value="<?php echo htmlspecialchars($row['description'] ?? ''); ?>" required>
            </label>

            <label>
                cost
                <input type="number" name="cost" value="<?php echo htmlspecialchars($row['cost'] ?? ''); ?>" required>
            </label>

            <label>
                average_length_of_stay
                <input type="number" name="average_length_of_stay" value="<?php echo htmlspecialchars($row['average_length_of_stay'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="drg.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
