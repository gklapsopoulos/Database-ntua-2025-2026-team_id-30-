<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $last_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['last_name']) . "'";
    $first_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['first_name']) . "'";
    $relationshipValue = "'" . mysqli_real_escape_string($conn, $_POST['relationship']) . "'";
    $AMKAValue = "'" . mysqli_real_escape_string($conn, $_POST['AMKA']) . "'";
    $relative_idKey = mysqli_real_escape_string($conn, $_POST['relative_id'] ?? '');
    $where = "`relative_id` = '$relative_idKey'";

    $sql = "UPDATE `patient_relatives` SET `last_name` = $last_nameValue, `first_name` = $first_nameValue, `relationship` = $relationshipValue, `AMKA` = $AMKAValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: patient_relatives.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $relative_idKey = mysqli_real_escape_string($conn, $_GET['relative_id'] ?? '');
    $where = "`relative_id` = '$relative_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `patient_relatives` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Patient Relative</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Patient Relative</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>relative_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>last_name: VARCHAR(25); required</li>
            <li>first_name: VARCHAR(25); required</li>
            <li>relationship: VARCHAR(25); required</li>
            <li>AMKA: BIGINT; required; must already exist in PATIENTS(AMKA)</li>
            <li>Primary key: relative_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="patient_relatives.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="relative_id" value="<?php echo htmlspecialchars($row['relative_id'] ?? ''); ?>">

            <label>
                relative_id
                <input type="number" name="relative_id" value="<?php echo htmlspecialchars($row['relative_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                last_name
                <input type="text" name="last_name" value="<?php echo htmlspecialchars($row['last_name'] ?? ''); ?>" required>
            </label>

            <label>
                first_name
                <input type="text" name="first_name" value="<?php echo htmlspecialchars($row['first_name'] ?? ''); ?>" required>
            </label>

            <label>
                relationship
                <input type="text" name="relationship" value="<?php echo htmlspecialchars($row['relationship'] ?? ''); ?>" required>
            </label>

            <label>
                AMKA
                <input type="number" name="AMKA" value="<?php echo htmlspecialchars($row['AMKA'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="patient_relatives.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
