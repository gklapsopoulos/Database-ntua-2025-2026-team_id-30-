<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $triage_idKey = mysqli_real_escape_string($conn, $_POST['triage_id'] ?? '');
    $where = "`triage_id` = '$triage_idKey'";
    $sql = "DELETE FROM `triage` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: triage.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $triage_idKey = mysqli_real_escape_string($conn, $_GET['triage_id'] ?? '');
    $where = "`triage_id` = '$triage_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `triage` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Triage</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Triage</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="triage.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Triage?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>triage_id:</strong> <?php echo htmlspecialchars($row['triage_id'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="triage_id" value="<?php echo htmlspecialchars($row['triage_id'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="triage.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
