<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $cleanlinessValue = "'" . mysqli_real_escape_string($conn, $_POST['cleanliness']) . "'";
    $nursing_care_qualityValue = "'" . mysqli_real_escape_string($conn, $_POST['nursing_care_quality']) . "'";
    $food_qualityValue = "'" . mysqli_real_escape_string($conn, $_POST['food_quality']) . "'";
    $total_expierienceValue = "'" . mysqli_real_escape_string($conn, $_POST['total_expierience']) . "'";
    $hospitalization_idKey = mysqli_real_escape_string($conn, $_POST['hospitalization_id'] ?? '');
    $where = "`hospitalization_id` = '$hospitalization_idKey'";

    $sql = "UPDATE `evaluation_hospitalization` SET `cleanliness` = $cleanlinessValue, `nursing_care_quality` = $nursing_care_qualityValue, `food_quality` = $food_qualityValue, `total_expierience` = $total_expierienceValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: evaluation_hospitalization.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $hospitalization_idKey = mysqli_real_escape_string($conn, $_GET['hospitalization_id'] ?? '');
    $where = "`hospitalization_id` = '$hospitalization_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `evaluation_hospitalization` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Evaluation Hospitalization</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Evaluation Hospitalization</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>hospitalization_id: INT; primary key; required; must already exist in HOSPITALIZATION(hospitalization_id)</li>
            <li>cleanliness: INT; required</li>
            <li>nursing_care_quality: INT; required</li>
            <li>food_quality: INT; required</li>
            <li>total_expierience: INT; required</li>
            <li>Primary key: hospitalization_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="evaluation_hospitalization.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="hospitalization_id" value="<?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?>">

            <label>
                hospitalization_id
                <input type="number" name="hospitalization_id" value="<?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                cleanliness
                <input type="number" name="cleanliness" value="<?php echo htmlspecialchars($row['cleanliness'] ?? ''); ?>" required>
            </label>

            <label>
                nursing_care_quality
                <input type="number" name="nursing_care_quality" value="<?php echo htmlspecialchars($row['nursing_care_quality'] ?? ''); ?>" required>
            </label>

            <label>
                food_quality
                <input type="number" name="food_quality" value="<?php echo htmlspecialchars($row['food_quality'] ?? ''); ?>" required>
            </label>

            <label>
                total_expierience
                <input type="number" name="total_expierience" value="<?php echo htmlspecialchars($row['total_expierience'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="evaluation_hospitalization.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
