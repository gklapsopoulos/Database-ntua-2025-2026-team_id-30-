<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $descriptionValue = ($_POST['description'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";
    $URLValue = "'" . mysqli_real_escape_string($conn, $_POST['URL']) . "'";
    $media_idKey = mysqli_real_escape_string($conn, $_POST['media_id'] ?? '');
    $where = "`media_id` = '$media_idKey'";

    $sql = "UPDATE `media_department` SET `description` = $descriptionValue, `URL` = $URLValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: media_department.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $media_idKey = mysqli_real_escape_string($conn, $_GET['media_id'] ?? '');
    $where = "`media_id` = '$media_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `media_department` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Department Media</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Department Media</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>media_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>description: VARCHAR(100); can be empty/NULL</li>
            <li>URL: VARCHAR(255); required</li>
            <li>Primary key: media_id</li>
            <li>Unique: URL</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="media_department.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="media_id" value="<?php echo htmlspecialchars($row['media_id'] ?? ''); ?>">

            <label>
                media_id
                <input type="number" name="media_id" value="<?php echo htmlspecialchars($row['media_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                description
                <input type="text" name="description" value="<?php echo htmlspecialchars($row['description'] ?? ''); ?>">
            </label>

            <label>
                URL
                <input type="text" name="URL" value="<?php echo htmlspecialchars($row['URL'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="media_department.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
