<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $symptomValue = "'" . mysqli_real_escape_string($conn, $_POST['symptom']) . "'";
    $triage_idValue = "'" . mysqli_real_escape_string($conn, $_POST['triage_id']) . "'";

    $sql = "INSERT INTO `triage_symptoms` (`symptom`, `triage_id`) VALUES ($symptomValue, $triage_idValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: triage_symptoms.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Triage Symptom</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Triage Symptom</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>symptom: VARCHAR(50); primary key; required</li>
            <li>triage_id: INT; primary key; required; must already exist in TRIAGE(triage_id)</li>
            <li>Primary key: triage_id, symptom</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                symptom
                <input type="text" name="symptom" required>
            </label>

            <label>
                triage_id
                <input type="number" name="triage_id" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="triage_symptoms.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
