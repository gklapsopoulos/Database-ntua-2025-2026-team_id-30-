<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $test_typeValue = "'" . mysqli_real_escape_string($conn, $_POST['test_type']) . "'";
    $test_codeValue = "'" . mysqli_real_escape_string($conn, $_POST['test_code']) . "'";
    $descriptionValue = "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";
    $costValue = "'" . mysqli_real_escape_string($conn, $_POST['cost']) . "'";

    $sql = "INSERT INTO `lab_tests` (`test_type`, `test_code`, `description`, `cost`) VALUES ($test_typeValue, $test_codeValue, $descriptionValue, $costValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: lab_tests.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Lab Test</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Lab Test</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>test_type: INT; required</li>
            <li>test_code: VARCHAR(250); primary key; required</li>
            <li>description: VARCHAR(250); required</li>
            <li>cost: INT; required</li>
            <li>Primary key: test_code</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                test_type
                <input type="number" name="test_type" required>
            </label>

            <label>
                test_code
                <input type="text" name="test_code" required>
            </label>

            <label>
                description
                <input type="text" name="description" required>
            </label>

            <label>
                cost
                <input type="number" name="cost" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="lab_tests.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
