<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $evaluationValue = "'" . mysqli_real_escape_string($conn, $_POST['evaluation']) . "'";
    $doctor_idKey = mysqli_real_escape_string($conn, $_POST['doctor_id'] ?? '');
    $hospitalization_idKey = mysqli_real_escape_string($conn, $_POST['hospitalization_id'] ?? '');
    $where = "`doctor_id` = '$doctor_idKey' AND `hospitalization_id` = '$hospitalization_idKey'";

    $sql = "UPDATE `doctor_evaluation` SET `evaluation` = $evaluationValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: doctor_evaluation.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $doctor_idKey = mysqli_real_escape_string($conn, $_GET['doctor_id'] ?? '');
    $hospitalization_idKey = mysqli_real_escape_string($conn, $_GET['hospitalization_id'] ?? '');
    $where = "`doctor_id` = '$doctor_idKey' AND `hospitalization_id` = '$hospitalization_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `doctor_evaluation` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Doctor Evaluation</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Doctor Evaluation</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>hospitalization_id: INT; primary key; required; must already exist in HOSPITALIZATION(hospitalization_id)</li>
            <li>doctor_id: INT; primary key; required; must already exist in DOCTOR(staff_id)</li>
            <li>evaluation: INT; required</li>
            <li>Primary key: doctor_id, hospitalization_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="doctor_evaluation.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="doctor_id" value="<?php echo htmlspecialchars($row['doctor_id'] ?? ''); ?>">
                <input type="hidden" name="hospitalization_id" value="<?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?>">

            <label>
                hospitalization_id
                <input type="number" name="hospitalization_id" value="<?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                doctor_id
                <input type="number" name="doctor_id" value="<?php echo htmlspecialchars($row['doctor_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                evaluation
                <input type="number" name="evaluation" value="<?php echo htmlspecialchars($row['evaluation'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="doctor_evaluation.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
