<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $procedure_codeKey = mysqli_real_escape_string($conn, $_POST['procedure_code'] ?? '');
    $where = "`procedure_code` = '$procedure_codeKey'";
    $sql = "DELETE FROM `medical_procedures` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: medical_procedures.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $procedure_codeKey = mysqli_real_escape_string($conn, $_GET['procedure_code'] ?? '');
    $where = "`procedure_code` = '$procedure_codeKey'";
$result = mysqli_query($conn, "SELECT * FROM `medical_procedures` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Medical Procedure</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Medical Procedure</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="medical_procedures.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Medical Procedures?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>procedure_code:</strong> <?php echo htmlspecialchars($row['procedure_code'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="procedure_code" value="<?php echo htmlspecialchars($row['procedure_code'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="medical_procedures.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
