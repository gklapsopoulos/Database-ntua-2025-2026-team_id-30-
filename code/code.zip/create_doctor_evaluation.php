<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $hospitalization_idValue = "'" . mysqli_real_escape_string($conn, $_POST['hospitalization_id']) . "'";
    $doctor_idValue = "'" . mysqli_real_escape_string($conn, $_POST['doctor_id']) . "'";
    $evaluationValue = "'" . mysqli_real_escape_string($conn, $_POST['evaluation']) . "'";

    $sql = "INSERT INTO `doctor_evaluation` (`hospitalization_id`, `doctor_id`, `evaluation`) VALUES ($hospitalization_idValue, $doctor_idValue, $evaluationValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: doctor_evaluation.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Doctor Evaluation</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Doctor Evaluation</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>hospitalization_id: INT; primary key; required; must already exist in HOSPITALIZATION(hospitalization_id)</li>
            <li>doctor_id: INT; primary key; required; must already exist in DOCTOR(staff_id)</li>
            <li>evaluation: INT; required</li>
            <li>Primary key: doctor_id, hospitalization_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                hospitalization_id
                <input type="number" name="hospitalization_id" required>
            </label>

            <label>
                doctor_id
                <input type="number" name="doctor_id" required>
            </label>

            <label>
                evaluation
                <input type="number" name="evaluation" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="doctor_evaluation.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
