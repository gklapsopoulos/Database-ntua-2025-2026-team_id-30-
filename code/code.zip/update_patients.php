<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $last_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['last_name']) . "'";
    $first_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['first_name']) . "'";
    $father_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['father_name']) . "'";
    $ageValue = "'" . mysqli_real_escape_string($conn, $_POST['age']) . "'";
    $genderValue = "'" . mysqli_real_escape_string($conn, $_POST['gender']) . "'";
    $weightValue = "'" . mysqli_real_escape_string($conn, $_POST['weight']) . "'";
    $heightValue = "'" . mysqli_real_escape_string($conn, $_POST['height']) . "'";
    $streetValue = "'" . mysqli_real_escape_string($conn, $_POST['street']) . "'";
    $street_numberValue = "'" . mysqli_real_escape_string($conn, $_POST['street_number']) . "'";
    $cityValue = "'" . mysqli_real_escape_string($conn, $_POST['city']) . "'";
    $insurance_providerValue = "'" . mysqli_real_escape_string($conn, $_POST['insurance_provider']) . "'";
    $emailValue = "'" . mysqli_real_escape_string($conn, $_POST['email']) . "'";
    $professionValue = "'" . mysqli_real_escape_string($conn, $_POST['profession']) . "'";
    $nationalityValue = "'" . mysqli_real_escape_string($conn, $_POST['nationality']) . "'";
    $AMKAKey = mysqli_real_escape_string($conn, $_POST['AMKA'] ?? '');
    $where = "`AMKA` = '$AMKAKey'";

    $sql = "UPDATE `patients` SET `last_name` = $last_nameValue, `first_name` = $first_nameValue, `father_name` = $father_nameValue, `age` = $ageValue, `gender` = $genderValue, `weight` = $weightValue, `height` = $heightValue, `street` = $streetValue, `street_number` = $street_numberValue, `city` = $cityValue, `insurance_provider` = $insurance_providerValue, `email` = $emailValue, `profession` = $professionValue, `nationality` = $nationalityValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: patients.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $AMKAKey = mysqli_real_escape_string($conn, $_GET['AMKA'] ?? '');
    $where = "`AMKA` = '$AMKAKey'";
$result = mysqli_query($conn, "SELECT * FROM `patients` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Patient</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Patient</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>AMKA: BIGINT; primary key; required</li>
            <li>last_name: VARCHAR(25); required</li>
            <li>first_name: VARCHAR(25); required</li>
            <li>father_name: VARCHAR(25); required</li>
            <li>age: INT; required</li>
            <li>gender: VARCHAR(10); required</li>
            <li>weight: NUMERIC(4,1); required</li>
            <li>height: INT; required</li>
            <li>street: VARCHAR(35); required</li>
            <li>street_number: INT; required</li>
            <li>city: VARCHAR(30); required</li>
            <li>insurance_provider: VARCHAR(35); required</li>
            <li>email: VARCHAR(50); required</li>
            <li>profession: VARCHAR(25); required</li>
            <li>nationality: VARCHAR(30); required</li>
            <li>Primary key: AMKA</li>
            <li>Check: age &gt;= 0</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="patients.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="AMKA" value="<?php echo htmlspecialchars($row['AMKA'] ?? ''); ?>">

            <label>
                AMKA
                <input type="number" name="AMKA" value="<?php echo htmlspecialchars($row['AMKA'] ?? ''); ?>" required disabled>
            </label>

            <label>
                last_name
                <input type="text" name="last_name" value="<?php echo htmlspecialchars($row['last_name'] ?? ''); ?>" required>
            </label>

            <label>
                first_name
                <input type="text" name="first_name" value="<?php echo htmlspecialchars($row['first_name'] ?? ''); ?>" required>
            </label>

            <label>
                father_name
                <input type="text" name="father_name" value="<?php echo htmlspecialchars($row['father_name'] ?? ''); ?>" required>
            </label>

            <label>
                age
                <input type="number" name="age" value="<?php echo htmlspecialchars($row['age'] ?? ''); ?>" required>
            </label>

            <label>
                gender
                <input type="text" name="gender" value="<?php echo htmlspecialchars($row['gender'] ?? ''); ?>" required>
            </label>

            <label>
                weight
                <input type="number" name="weight" value="<?php echo htmlspecialchars($row['weight'] ?? ''); ?>" step="any" required>
            </label>

            <label>
                height
                <input type="number" name="height" value="<?php echo htmlspecialchars($row['height'] ?? ''); ?>" required>
            </label>

            <label>
                street
                <input type="text" name="street" value="<?php echo htmlspecialchars($row['street'] ?? ''); ?>" required>
            </label>

            <label>
                street_number
                <input type="number" name="street_number" value="<?php echo htmlspecialchars($row['street_number'] ?? ''); ?>" required>
            </label>

            <label>
                city
                <input type="text" name="city" value="<?php echo htmlspecialchars($row['city'] ?? ''); ?>" required>
            </label>

            <label>
                insurance_provider
                <input type="text" name="insurance_provider" value="<?php echo htmlspecialchars($row['insurance_provider'] ?? ''); ?>" required>
            </label>

            <label>
                email
                <input type="email" name="email" value="<?php echo htmlspecialchars($row['email'] ?? ''); ?>" required>
            </label>

            <label>
                profession
                <input type="text" name="profession" value="<?php echo htmlspecialchars($row['profession'] ?? ''); ?>" required>
            </label>

            <label>
                nationality
                <input type="text" name="nationality" value="<?php echo htmlspecialchars($row['nationality'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="patients.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
