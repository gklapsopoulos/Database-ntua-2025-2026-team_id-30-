<?php
include 'db_connection.php';
include 'table_helpers.php';

$conn = OpenCon();

function countRows($conn, $table) {
    $result = mysqli_query($conn, "SELECT COUNT(*) FROM " . quoteIdentifier($table));
    return $result ? mysqli_fetch_row($result)[0] : 'n/a';
}

$waitingLimit = isset($_GET['waiting_limit']) ? (int)$_GET['waiting_limit'] : 10;
if ($waitingLimit < 1) {
    $waitingLimit = 1;
}

$waitingRows = array();
$waitingError = '';
$waitingSql = "SELECT p.AMKA, p.first_name, p.last_name, tr.urgency_level, tr.arrival_time
    FROM TRIAGE tr
    JOIN PATIENTS p ON tr.AMKA = p.AMKA
    WHERE tr.service_time IS NULL
    ORDER BY tr.urgency_level ASC, tr.arrival_time ASC
    LIMIT ?";
try {
    $stmt = $conn->prepare($waitingSql);
    if (!$stmt) {
        $waitingError = $conn->error;
    } else {
        $stmt->bind_param("i", $waitingLimit);
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result) {
                while ($row = $result->fetch_assoc()) {
                    $waitingRows[] = $row;
                }
                $result->free();
            }
        } else {
            $waitingError = $stmt->error;
        }
        $stmt->close();
    }
} catch (mysqli_sql_exception $exception) {
    $waitingError = $exception->getMessage();
}

$tables = getTables($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Database Demo</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <nav id="nav-bar">
        <div id="navbar-div">
            <a id="nav-bar-text">Hospital Database Demo - Landing Page</a>
            <a id="navbar-items" href="/hospital_app/">Landing</a>
        </div>
    </nav>
    <main class="container">
        <section class="card waiting-panel">
            <div class="waiting-header">
                <div>
                    <h3>Patients waiting</h3>
                    <p class="muted"><?php echo count($waitingRows); ?> patients shown</p>
                </div>
                <form class="waiting-form" method="GET">
                    <label>
                        Number of patients
                        <input type="number" name="waiting_limit" min="1" value="<?php echo h($waitingLimit); ?>" required>
                    </label>
                    <div class="form-actions">
                        <button type="submit">Run</button>
                    </div>
                </form>
            </div>

            <?php if ($waitingError): ?>
                <p class="error"><?php echo h($waitingError); ?></p>
            <?php else: ?>
                <div class="table-wrap waiting-table">
                    <table>
                        <thead>
                            <tr>
                                <th>AMKA</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Urgency Level</th>
                                <th>Arrival Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($waitingRows) === 0): ?>
                                <tr><td colspan="5">No waiting patients found.</td></tr>
                            <?php else: ?>
                                <?php foreach ($waitingRows as $row): ?>
                                    <tr>
                                        <td><?php echo displayValue($row['AMKA'] ?? null); ?></td>
                                        <td><?php echo displayValue($row['first_name'] ?? null); ?></td>
                                        <td><?php echo displayValue($row['last_name'] ?? null); ?></td>
                                        <td><?php echo displayValue($row['urgency_level'] ?? null); ?></td>
                                        <td><?php echo displayValue($row['arrival_time'] ?? null); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>

        <section class="grid">
            <div class="card highlight">
                <h3>Queries</h3>
                <p class="muted">15 assignment queries</p>
                <a class="btn" href="queries.php">Show</a>
            </div>

            <?php foreach ($tables as $table): ?>
                <div class="card highlight">
                    <h3><?php echo h(tableTitle($table)); ?></h3>
                    <p class="muted"><?php echo h(countRows($conn, $table)); ?> rows in <?php echo h($table); ?></p>
                    <?php $href = strtolower($table) . '.php'; ?>
                    <a class="btn" href="<?php echo h($href); ?>">Show</a>
                </div>
            <?php endforeach; ?>
        </section>
    </main>
</body>
</html>
<?php CloseCon($conn); ?>
