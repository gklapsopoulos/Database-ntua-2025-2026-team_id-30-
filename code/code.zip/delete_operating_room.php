<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $room_idKey = mysqli_real_escape_string($conn, $_POST['room_id'] ?? '');
    $where = "`room_id` = '$room_idKey'";
    $sql = "DELETE FROM `operating_room` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: operating_room.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $room_idKey = mysqli_real_escape_string($conn, $_GET['room_id'] ?? '');
    $where = "`room_id` = '$room_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `operating_room` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Operating Room</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Operating Room</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="operating_room.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Operating Room?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>room_id:</strong> <?php echo htmlspecialchars($row['room_id'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="room_id" value="<?php echo htmlspecialchars($row['room_id'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="operating_room.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
