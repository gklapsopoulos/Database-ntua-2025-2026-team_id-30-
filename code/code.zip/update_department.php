<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $descriptionValue = "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";
    $floorValue = "'" . mysqli_real_escape_string($conn, $_POST['floor']) . "'";
    $buildingValue = "'" . mysqli_real_escape_string($conn, $_POST['building']) . "'";
    $bed_countValue = "'" . mysqli_real_escape_string($conn, $_POST['bed_count']) . "'";
    $director_idValue = "'" . mysqli_real_escape_string($conn, $_POST['director_id']) . "'";
    $media_idValue = "'" . mysqli_real_escape_string($conn, $_POST['media_id']) . "'";
    $department_nameKey = mysqli_real_escape_string($conn, $_POST['department_name'] ?? '');
    $where = "`department_name` = '$department_nameKey'";

    $sql = "UPDATE `department` SET `description` = $descriptionValue, `floor` = $floorValue, `building` = $buildingValue, `bed_count` = $bed_countValue, `director_id` = $director_idValue, `media_id` = $media_idValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: department.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $department_nameKey = mysqli_real_escape_string($conn, $_GET['department_name'] ?? '');
    $where = "`department_name` = '$department_nameKey'";
$result = mysqli_query($conn, "SELECT * FROM `department` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Department</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Department</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>department_name: VARCHAR(50); primary key; required</li>
            <li>description: VARCHAR(50); required</li>
            <li>floor: INT; required</li>
            <li>building: VARCHAR(25); required</li>
            <li>bed_count: INT; required</li>
            <li>director_id: INT; required; unique value; must already exist in DOCTOR(staff_id)</li>
            <li>media_id: INT; required; must already exist in MEDIA_DEPARTMENT(media_id)</li>
            <li>Primary key: department_name</li>
            <li>Check: bed_count &gt;= 0</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="department.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="department_name" value="<?php echo htmlspecialchars($row['department_name'] ?? ''); ?>">

            <label>
                department_name
                <input type="text" name="department_name" value="<?php echo htmlspecialchars($row['department_name'] ?? ''); ?>" required disabled>
            </label>

            <label>
                description
                <input type="text" name="description" value="<?php echo htmlspecialchars($row['description'] ?? ''); ?>" required>
            </label>

            <label>
                floor
                <input type="number" name="floor" value="<?php echo htmlspecialchars($row['floor'] ?? ''); ?>" required>
            </label>

            <label>
                building
                <input type="text" name="building" value="<?php echo htmlspecialchars($row['building'] ?? ''); ?>" required>
            </label>

            <label>
                bed_count
                <input type="number" name="bed_count" value="<?php echo htmlspecialchars($row['bed_count'] ?? ''); ?>" required>
            </label>

            <label>
                director_id
                <input type="number" name="director_id" value="<?php echo htmlspecialchars($row['director_id'] ?? ''); ?>" required>
            </label>

            <label>
                media_id
                <input type="number" name="media_id" value="<?php echo htmlspecialchars($row['media_id'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="department.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
