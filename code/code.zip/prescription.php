<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `prescription` ORDER BY `medication_id`, `prescription_start_date`, `staff_id`, `AMKA` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prescription</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Prescription</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_prescription.php">Create Prescription</a>
        <span class="muted">Showing up to 300 rows from prescription</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>prescription_start_date</th>
                    <th>prescription_end_date</th>
                    <th>dosage</th>
                    <th>frequency</th>
                    <th>medication_id</th>
                    <th>staff_id</th>
                    <th>AMKA</th>
                    <th>hospitalization_id</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="9">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['prescription_start_date'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['prescription_end_date'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['dosage'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['frequency'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['medication_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['staff_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['AMKA'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_prescription.php?medication_id=<?php echo urlencode($row['medication_id']); ?>&prescription_start_date=<?php echo urlencode($row['prescription_start_date']); ?>&staff_id=<?php echo urlencode($row['staff_id']); ?>&AMKA=<?php echo urlencode($row['AMKA']); ?>">Edit</a>
                                <a class="btn danger" href="delete_prescription.php?medication_id=<?php echo urlencode($row['medication_id']); ?>&prescription_start_date=<?php echo urlencode($row['prescription_start_date']); ?>&staff_id=<?php echo urlencode($row['staff_id']); ?>&AMKA=<?php echo urlencode($row['AMKA']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
