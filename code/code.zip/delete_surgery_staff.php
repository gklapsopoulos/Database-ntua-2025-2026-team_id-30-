<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $staff_idKey = mysqli_real_escape_string($conn, $_POST['staff_id'] ?? '');
    $procedure_hospitalization_idKey = mysqli_real_escape_string($conn, $_POST['procedure_hospitalization_id'] ?? '');
    $where = "`staff_id` = '$staff_idKey' AND `procedure_hospitalization_id` = '$procedure_hospitalization_idKey'";
    $sql = "DELETE FROM `surgery_staff` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: surgery_staff.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $staff_idKey = mysqli_real_escape_string($conn, $_GET['staff_id'] ?? '');
    $procedure_hospitalization_idKey = mysqli_real_escape_string($conn, $_GET['procedure_hospitalization_id'] ?? '');
    $where = "`staff_id` = '$staff_idKey' AND `procedure_hospitalization_id` = '$procedure_hospitalization_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `surgery_staff` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Surgery Staff</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Surgery Staff</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="surgery_staff.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Surgery Staff?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>staff_id:</strong> <?php echo htmlspecialchars($row['staff_id'] ?? ''); ?></li>
                <li><strong>procedure_hospitalization_id:</strong> <?php echo htmlspecialchars($row['procedure_hospitalization_id'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>">
                <input type="hidden" name="procedure_hospitalization_id" value="<?php echo htmlspecialchars($row['procedure_hospitalization_id'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="surgery_staff.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
