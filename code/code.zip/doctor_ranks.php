<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `doctor_ranks` ORDER BY `rank` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Ranks</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Doctor Ranks</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_doctor_ranks.php">Create Doctor Rank</a>
        <span class="muted">Showing up to 300 rows from doctor_ranks</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>rank</th>
                    <th>description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="3">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['rank'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['description'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_doctor_ranks.php?rank=<?php echo urlencode($row['rank']); ?>">Edit</a>
                                <a class="btn danger" href="delete_doctor_ranks.php?rank=<?php echo urlencode($row['rank']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
