<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $phoneKey = mysqli_real_escape_string($conn, $_POST['phone'] ?? '');
    $AMKAKey = mysqli_real_escape_string($conn, $_POST['AMKA'] ?? '');
    $where = "`phone` = '$phoneKey' AND `AMKA` = '$AMKAKey'";
    $sql = "DELETE FROM `patient_phone` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: patient_phone.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $phoneKey = mysqli_real_escape_string($conn, $_GET['phone'] ?? '');
    $AMKAKey = mysqli_real_escape_string($conn, $_GET['AMKA'] ?? '');
    $where = "`phone` = '$phoneKey' AND `AMKA` = '$AMKAKey'";
$result = mysqli_query($conn, "SELECT * FROM `patient_phone` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Patient Phone</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Patient Phone</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="patient_phone.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Patient Phone?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>phone:</strong> <?php echo htmlspecialchars($row['phone'] ?? ''); ?></li>
                <li><strong>AMKA:</strong> <?php echo htmlspecialchars($row['AMKA'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="phone" value="<?php echo htmlspecialchars($row['phone'] ?? ''); ?>">
                <input type="hidden" name="AMKA" value="<?php echo htmlspecialchars($row['AMKA'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="patient_phone.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
