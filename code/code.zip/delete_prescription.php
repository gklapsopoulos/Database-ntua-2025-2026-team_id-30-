<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $medication_idKey = mysqli_real_escape_string($conn, $_POST['medication_id'] ?? '');
    $prescription_start_dateKey = mysqli_real_escape_string($conn, $_POST['prescription_start_date'] ?? '');
    $staff_idKey = mysqli_real_escape_string($conn, $_POST['staff_id'] ?? '');
    $AMKAKey = mysqli_real_escape_string($conn, $_POST['AMKA'] ?? '');
    $where = "`medication_id` = '$medication_idKey' AND `prescription_start_date` = '$prescription_start_dateKey' AND `staff_id` = '$staff_idKey' AND `AMKA` = '$AMKAKey'";
    $sql = "DELETE FROM `prescription` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: prescription.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $medication_idKey = mysqli_real_escape_string($conn, $_GET['medication_id'] ?? '');
    $prescription_start_dateKey = mysqli_real_escape_string($conn, $_GET['prescription_start_date'] ?? '');
    $staff_idKey = mysqli_real_escape_string($conn, $_GET['staff_id'] ?? '');
    $AMKAKey = mysqli_real_escape_string($conn, $_GET['AMKA'] ?? '');
    $where = "`medication_id` = '$medication_idKey' AND `prescription_start_date` = '$prescription_start_dateKey' AND `staff_id` = '$staff_idKey' AND `AMKA` = '$AMKAKey'";
$result = mysqli_query($conn, "SELECT * FROM `prescription` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Prescription</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Prescription</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="prescription.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Prescription?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>medication_id:</strong> <?php echo htmlspecialchars($row['medication_id'] ?? ''); ?></li>
                <li><strong>prescription_start_date:</strong> <?php echo htmlspecialchars($row['prescription_start_date'] ?? ''); ?></li>
                <li><strong>staff_id:</strong> <?php echo htmlspecialchars($row['staff_id'] ?? ''); ?></li>
                <li><strong>AMKA:</strong> <?php echo htmlspecialchars($row['AMKA'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="medication_id" value="<?php echo htmlspecialchars($row['medication_id'] ?? ''); ?>">
                <input type="hidden" name="prescription_start_date" value="<?php echo htmlspecialchars($row['prescription_start_date'] ?? ''); ?>">
                <input type="hidden" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>">
                <input type="hidden" name="AMKA" value="<?php echo htmlspecialchars($row['AMKA'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="prescription.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
