<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $prescription_end_dateValue = "'" . mysqli_real_escape_string($conn, $_POST['prescription_end_date']) . "'";
    $dosageValue = "'" . mysqli_real_escape_string($conn, $_POST['dosage']) . "'";
    $frequencyValue = "'" . mysqli_real_escape_string($conn, $_POST['frequency']) . "'";
    $hospitalization_idValue = "'" . mysqli_real_escape_string($conn, $_POST['hospitalization_id']) . "'";
    $medication_idKey = mysqli_real_escape_string($conn, $_POST['medication_id'] ?? '');
    $prescription_start_dateKey = mysqli_real_escape_string($conn, $_POST['prescription_start_date'] ?? '');
    $staff_idKey = mysqli_real_escape_string($conn, $_POST['staff_id'] ?? '');
    $AMKAKey = mysqli_real_escape_string($conn, $_POST['AMKA'] ?? '');
    $where = "`medication_id` = '$medication_idKey' AND `prescription_start_date` = '$prescription_start_dateKey' AND `staff_id` = '$staff_idKey' AND `AMKA` = '$AMKAKey'";

    $sql = "UPDATE `prescription` SET `prescription_end_date` = $prescription_end_dateValue, `dosage` = $dosageValue, `frequency` = $frequencyValue, `hospitalization_id` = $hospitalization_idValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: prescription.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $medication_idKey = mysqli_real_escape_string($conn, $_GET['medication_id'] ?? '');
    $prescription_start_dateKey = mysqli_real_escape_string($conn, $_GET['prescription_start_date'] ?? '');
    $staff_idKey = mysqli_real_escape_string($conn, $_GET['staff_id'] ?? '');
    $AMKAKey = mysqli_real_escape_string($conn, $_GET['AMKA'] ?? '');
    $where = "`medication_id` = '$medication_idKey' AND `prescription_start_date` = '$prescription_start_dateKey' AND `staff_id` = '$staff_idKey' AND `AMKA` = '$AMKAKey'";
$result = mysqli_query($conn, "SELECT * FROM `prescription` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Prescription</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Prescription</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>prescription_start_date: DATE; primary key; required</li>
            <li>prescription_end_date: DATE; required</li>
            <li>dosage: VARCHAR(50); required</li>
            <li>frequency: VARCHAR(50); required</li>
            <li>medication_id: INT; primary key; required; must already exist in MEDICATION(medication_id)</li>
            <li>staff_id: INT; primary key; required; must already exist in DOCTOR(staff_id)</li>
            <li>AMKA: BIGINT; primary key; required; must already exist in PATIENTS(AMKA)</li>
            <li>hospitalization_id: INT; required; must already exist in HOSPITALIZATION(hospitalization_id)</li>
            <li>Primary key: medication_id, prescription_start_date, staff_id, AMKA</li>
            <li>Check: prescription_start_date &lt;= prescription_end_date</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="prescription.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="medication_id" value="<?php echo htmlspecialchars($row['medication_id'] ?? ''); ?>">
                <input type="hidden" name="prescription_start_date" value="<?php echo htmlspecialchars($row['prescription_start_date'] ?? ''); ?>">
                <input type="hidden" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>">
                <input type="hidden" name="AMKA" value="<?php echo htmlspecialchars($row['AMKA'] ?? ''); ?>">

            <label>
                prescription_start_date
                <input type="date" name="prescription_start_date" value="<?php echo htmlspecialchars($row['prescription_start_date'] ?? ''); ?>" required disabled>
            </label>

            <label>
                prescription_end_date
                <input type="date" name="prescription_end_date" value="<?php echo htmlspecialchars($row['prescription_end_date'] ?? ''); ?>" required>
            </label>

            <label>
                dosage
                <input type="text" name="dosage" value="<?php echo htmlspecialchars($row['dosage'] ?? ''); ?>" required>
            </label>

            <label>
                frequency
                <input type="text" name="frequency" value="<?php echo htmlspecialchars($row['frequency'] ?? ''); ?>" required>
            </label>

            <label>
                medication_id
                <input type="number" name="medication_id" value="<?php echo htmlspecialchars($row['medication_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                staff_id
                <input type="number" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                AMKA
                <input type="number" name="AMKA" value="<?php echo htmlspecialchars($row['AMKA'] ?? ''); ?>" required disabled>
            </label>

            <label>
                hospitalization_id
                <input type="number" name="hospitalization_id" value="<?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="prescription.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
