<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $room_idValue = "'" . mysqli_real_escape_string($conn, $_POST['room_id']) . "'";
    $media_idValue = "'" . mysqli_real_escape_string($conn, $_POST['media_id']) . "'";
    $descriptionValue = "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";

    $sql = "INSERT INTO `operating_room` (`room_id`, `media_id`, `description`) VALUES ($room_idValue, $media_idValue, $descriptionValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: operating_room.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Operating Room</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Operating Room</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>room_id: INT; primary key; required</li>
            <li>media_id: INT; required; must already exist in MEDIA_OPERATING_ROOMS(media_id)</li>
            <li>description: VARCHAR(200); required</li>
            <li>Primary key: room_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                room_id
                <input type="number" name="room_id" required>
            </label>

            <label>
                media_id
                <input type="number" name="media_id" required>
            </label>

            <label>
                description
                <input type="text" name="description" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="operating_room.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
