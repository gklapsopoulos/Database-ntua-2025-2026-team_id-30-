<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $staff_idValue = "'" . mysqli_real_escape_string($conn, $_POST['staff_id']) . "'";
    $procedure_hospitalization_idValue = "'" . mysqli_real_escape_string($conn, $_POST['procedure_hospitalization_id']) . "'";

    $sql = "INSERT INTO `surgery_staff` (`staff_id`, `procedure_hospitalization_id`) VALUES ($staff_idValue, $procedure_hospitalization_idValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: surgery_staff.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Surgery Staff</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Surgery Staff</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>staff_id: INT; primary key; required; must already exist in STAFF(staff_id)</li>
            <li>procedure_hospitalization_id: INT; primary key; required; must already exist in hospitalization_procedure(procedure_hospitalization_id)</li>
            <li>Primary key: staff_id, procedure_hospitalization_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                staff_id
                <input type="number" name="staff_id" required>
            </label>

            <label>
                procedure_hospitalization_id
                <input type="number" name="procedure_hospitalization_id" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="surgery_staff.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
