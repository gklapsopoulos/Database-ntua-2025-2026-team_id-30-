<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $shift_dateValue = "'" . mysqli_real_escape_string($conn, $_POST['shift_date']) . "'";
    $slotValue = "'" . mysqli_real_escape_string($conn, $_POST['slot']) . "'";
    $department_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['department_name']) . "'";
    $shift_statusValue = "'" . mysqli_real_escape_string($conn, $_POST['shift_status']) . "'";

    $sql = "INSERT INTO `shifts` (`shift_date`, `slot`, `department_name`, `shift_status`) VALUES ($shift_dateValue, $slotValue, $department_nameValue, $shift_statusValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: shifts.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Shift</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Shift</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>shift_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>shift_date: DATE; required</li>
            <li>slot: VARCHAR(15); required</li>
            <li>department_name: VARCHAR(50); required; must already exist in DEPARTMENT(department_name)</li>
            <li>shift_status: VARCHAR(10); required</li>
            <li>Primary key: shift_id</li>
            <li>Check: slot IN (&#039;morning&#039;, &#039;afternoon&#039;, &#039;night&#039;)</li>
            <li>Check: shift_status IN (&#039;full&#039;, &#039;not full&#039;)</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                shift_id (auto)
                <input type="number" name="shift_id" disabled>
            </label>

            <label>
                shift_date
                <input type="date" name="shift_date" required>
            </label>

            <label>
                slot
                <select name="slot" required>
                    <option value="morning">morning</option>
                    <option value="afternoon">afternoon</option>
                    <option value="night">night</option>
                </select>
            </label>

            <label>
                department_name
                <input type="text" name="department_name" required>
            </label>

            <label>
                shift_status
                <select name="shift_status" required>
                    <option value="full">full</option>
                    <option value="not full">not full</option>
                </select>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="shifts.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
