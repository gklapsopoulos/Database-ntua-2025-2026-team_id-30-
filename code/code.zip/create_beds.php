<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $bed_numberValue = "'" . mysqli_real_escape_string($conn, $_POST['bed_number']) . "'";
    $typeValue = "'" . mysqli_real_escape_string($conn, $_POST['type']) . "'";
    $statusValue = "'" . mysqli_real_escape_string($conn, $_POST['status']) . "'";
    $department_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['department_name']) . "'";

    $sql = "INSERT INTO `beds` (`bed_number`, `type`, `status`, `department_name`) VALUES ($bed_numberValue, $typeValue, $statusValue, $department_nameValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: beds.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Bed</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Bed</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>bed_number: INT; primary key; required</li>
            <li>type: VARCHAR(25); required</li>
            <li>status: VARCHAR(25); required</li>
            <li>department_name: VARCHAR(50); required; must already exist in DEPARTMENT(department_name)</li>
            <li>Primary key: bed_number</li>
            <li>Check: type IN (&#039;ICU&#039;, &#039;single-bed&#039;, &#039;multi-bed&#039;, &#039;Isolation&#039;, &#039;Recovery-bed&#039;, &#039;Double-room-bed&#039;)</li>
            <li>Check: status IN (&#039;occupied&#039;, &#039;not occupied&#039;, &#039;maintenance&#039;)</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                bed_number
                <input type="number" name="bed_number" required>
            </label>

            <label>
                type
                <select name="type" required>
                    <option value="ICU">ICU</option>
                    <option value="single-bed">single-bed</option>
                    <option value="multi-bed">multi-bed</option>
                    <option value="Isolation">Isolation</option>
                    <option value="Recovery-bed">Recovery-bed</option>
                    <option value="Double-room-bed">Double-room-bed</option>
                </select>
            </label>

            <label>
                status
                <select name="status" required>
                    <option value="occupied">occupied</option>
                    <option value="not occupied">not occupied</option>
                    <option value="maintenance">maintenance</option>
                </select>
            </label>

            <label>
                department_name
                <input type="text" name="department_name" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="beds.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
