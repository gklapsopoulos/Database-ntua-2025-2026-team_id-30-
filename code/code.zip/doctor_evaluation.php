<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `doctor_evaluation` ORDER BY `doctor_id`, `hospitalization_id` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Evaluation</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Doctor Evaluation</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_doctor_evaluation.php">Create Doctor Evaluation</a>
        <span class="muted">Showing up to 300 rows from doctor_evaluation</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>hospitalization_id</th>
                    <th>doctor_id</th>
                    <th>evaluation</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="4">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['doctor_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['evaluation'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_doctor_evaluation.php?doctor_id=<?php echo urlencode($row['doctor_id']); ?>&hospitalization_id=<?php echo urlencode($row['hospitalization_id']); ?>">Edit</a>
                                <a class="btn danger" href="delete_doctor_evaluation.php?doctor_id=<?php echo urlencode($row['doctor_id']); ?>&hospitalization_id=<?php echo urlencode($row['hospitalization_id']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
