<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `drg` ORDER BY `drg_code` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drg</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Drg</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_drg.php">Create Drg</a>
        <span class="muted">Showing up to 300 rows from drg</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>drg_code</th>
                    <th>description</th>
                    <th>cost</th>
                    <th>average_length_of_stay</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="5">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['drg_code'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['description'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['cost'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['average_length_of_stay'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_drg.php?drg_code=<?php echo urlencode($row['drg_code']); ?>">Edit</a>
                                <a class="btn danger" href="delete_drg.php?drg_code=<?php echo urlencode($row['drg_code']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
