<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `evaluation_hospitalization` ORDER BY `hospitalization_id` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evaluation Hospitalization</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Evaluation Hospitalization</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_evaluation_hospitalization.php">Create Evaluation Hospitalization</a>
        <span class="muted">Showing up to 300 rows from evaluation_hospitalization</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>hospitalization_id</th>
                    <th>cleanliness</th>
                    <th>nursing_care_quality</th>
                    <th>food_quality</th>
                    <th>total_expierience</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="6">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['cleanliness'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['nursing_care_quality'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['food_quality'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['total_expierience'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_evaluation_hospitalization.php?hospitalization_id=<?php echo urlencode($row['hospitalization_id']); ?>">Edit</a>
                                <a class="btn danger" href="delete_evaluation_hospitalization.php?hospitalization_id=<?php echo urlencode($row['hospitalization_id']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
