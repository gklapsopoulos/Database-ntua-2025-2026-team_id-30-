<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $AMKAValue = "'" . mysqli_real_escape_string($conn, $_POST['AMKA']) . "'";
    $emailValue = "'" . mysqli_real_escape_string($conn, $_POST['email']) . "'";
    $hire_dateValue = "'" . mysqli_real_escape_string($conn, $_POST['hire_date']) . "'";
    $ageValue = "'" . mysqli_real_escape_string($conn, $_POST['age']) . "'";
    $last_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['last_name']) . "'";
    $first_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['first_name']) . "'";
    $staff_typeValue = "'" . mysqli_real_escape_string($conn, $_POST['staff_type']) . "'";
    $media_idValue = "'" . mysqli_real_escape_string($conn, $_POST['media_id']) . "'";
    $working_statusValue = "'" . mysqli_real_escape_string($conn, $_POST['working_status']) . "'";
    $staff_idKey = mysqli_real_escape_string($conn, $_POST['staff_id'] ?? '');
    $where = "`staff_id` = '$staff_idKey'";

    $sql = "UPDATE `staff` SET `AMKA` = $AMKAValue, `email` = $emailValue, `hire_date` = $hire_dateValue, `age` = $ageValue, `last_name` = $last_nameValue, `first_name` = $first_nameValue, `staff_type` = $staff_typeValue, `media_id` = $media_idValue, `working_status` = $working_statusValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: staff.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $staff_idKey = mysqli_real_escape_string($conn, $_GET['staff_id'] ?? '');
    $where = "`staff_id` = '$staff_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `staff` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Staff</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Staff</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>staff_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>AMKA: BIGINT; required; unique value</li>
            <li>email: VARCHAR(50); required</li>
            <li>hire_date: DATE; required</li>
            <li>age: INT; required</li>
            <li>last_name: VARCHAR(20); required</li>
            <li>first_name: VARCHAR(20); required</li>
            <li>staff_type: VARCHAR(25); required</li>
            <li>media_id: INT; required; must already exist in MEDIA_STAFF(media_id)</li>
            <li>working_status: BOOLEAN; required</li>
            <li>Primary key: staff_id</li>
            <li>Check: staff_type IN (&#039;doctor&#039;, &#039;nurse&#039;, &#039;administrative staff&#039;)</li>
            <li>Check: age &gt;= 18</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="staff.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>">

            <label>
                staff_id
                <input type="number" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                AMKA
                <input type="number" name="AMKA" value="<?php echo htmlspecialchars($row['AMKA'] ?? ''); ?>" required>
            </label>

            <label>
                email
                <input type="email" name="email" value="<?php echo htmlspecialchars($row['email'] ?? ''); ?>" required>
            </label>

            <label>
                hire_date
                <input type="date" name="hire_date" value="<?php echo htmlspecialchars($row['hire_date'] ?? ''); ?>" required>
            </label>

            <label>
                age
                <input type="number" name="age" value="<?php echo htmlspecialchars($row['age'] ?? ''); ?>" required>
            </label>

            <label>
                last_name
                <input type="text" name="last_name" value="<?php echo htmlspecialchars($row['last_name'] ?? ''); ?>" required>
            </label>

            <label>
                first_name
                <input type="text" name="first_name" value="<?php echo htmlspecialchars($row['first_name'] ?? ''); ?>" required>
            </label>

            <label>
                staff_type
                <select name="staff_type" required>
                    <option value="doctor" <?php echo $row['staff_type'] === 'doctor' ? 'selected' : ''; ?>>doctor</option>
                    <option value="nurse" <?php echo $row['staff_type'] === 'nurse' ? 'selected' : ''; ?>>nurse</option>
                    <option value="administrative staff" <?php echo $row['staff_type'] === 'administrative staff' ? 'selected' : ''; ?>>administrative staff</option>
                </select>
            </label>

            <label>
                media_id
                <input type="number" name="media_id" value="<?php echo htmlspecialchars($row['media_id'] ?? ''); ?>" required>
            </label>

            <label>
                working_status
                <input type="number" name="working_status" value="<?php echo htmlspecialchars($row['working_status'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="staff.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
