<?php
function getQueryDefinitions() {
    return array(
        1 => array(
            'title' => '1. Revenue by department/year',
            'params' => array(),
            'sql' => "SELECT YEAR(h.admission_date) AS year,
    h.department_name AS department_name,
    h.drg_code AS KEN,
    p.insurance_provider AS insurance_provider,
    COUNT(*) AS hospitalization_count,
    COUNT(*) *
    (
        SELECT cost
        FROM DRG
        WHERE drg_code = h.drg_code
    ) AS base_cost,
    SUM(current_cost) - COUNT(*) *
    (
        SELECT cost
        FROM DRG
        WHERE drg_code = h.drg_code
    ) AS extra_cost,
    SUM(current_cost) AS Total_Cost
FROM HOSPITALIZATION h
JOIN TRIAGE AS t ON h.triage_id = t.triage_id
JOIN PATIENTS p ON p.AMKA = t.AMKA
WHERE h.discharge_date IS NOT NULL
GROUP BY h.drg_code,
    p.insurance_provider,
    YEAR(h.admission_date),
    h.department_name
ORDER BY YEAR(h.admission_date),
    h.department_name,
    h.drg_code,
    p.insurance_provider"
        ),
        2 => array(
            'title' => '2. Doctors by specialty',
            'params' => array(
                array('name' => 'specialty', 'label' => 'Specialty', 'type' => 'text', 'default' => 'Cardiology')
            ),
            'sql' => "SELECT s.last_name,
       s.first_name,
       s.AMKA,
       CASE
           WHEN EXISTS
           (
               SELECT 1
               FROM SHIFTS sh
               JOIN DUTY_TEAM dt ON dt.shift_id = sh.shift_id
               WHERE s.staff_id = dt.staff_id
               AND YEAR(sh.shift_date) = YEAR(CURRENT_DATE)
               AND sh.shift_date < CURRENT_DATE
               AND sh.shift_status = 'full'
           )
           THEN 'YES'
           ELSE 'NO'
       END AS shift_current_year,
       (
           SELECT COUNT(*)
           FROM SURGERY
           WHERE surgeon_id = s.staff_id
       ) AS surgery_count
FROM STAFF s
JOIN DOCTOR d ON s.staff_id = d.staff_id
WHERE d.specialty = ?"
        ),
        3 => array(
            'title' => '3. Frequent same-department patients',
            'params' => array(),
            'sql' => "SELECT p.AMKA,
       SUM(h.current_cost) AS total_cost,
       h.department_name
FROM PATIENTS p
JOIN TRIAGE t ON p.AMKA = t.AMKA
JOIN HOSPITALIZATION h ON h.triage_id = t.triage_id
GROUP BY p.AMKA, h.department_name
HAVING COUNT(*) > 3"
        ),
        4 => array(
            'title' => '4. Doctor evaluation averages',
            'params' => array(
                array('name' => 'staff_id', 'label' => 'Doctor staff ID', 'type' => 'number', 'default' => '5')
            ),
            'sql' => "SELECT s.AMKA,
    s.last_name,
    s.first_name,
    (
        SELECT AVG(evaluation)
        FROM DOCTOR_EVALUATION de
        WHERE de.doctor_id = s.staff_id
    ) AS average_doctor_evaluation,
    (
        SELECT AVG(total_expierience)
        FROM EVALUATION_HOSPITALIZATION eh
        WHERE eh.hospitalization_id IN (
            SELECT hp.hospitalization_id AS hospitalization_id
            FROM SURGERY sur
            NATURAL JOIN HOSPITALIZATION_PROCEDURE hp
            WHERE sur.surgeon_id = s.staff_id

            UNION

            SELECT hospitalization_id AS hospitalization_id
            FROM HOSPITALIZATION_TEST
            WHERE s.staff_id = staff_id

            UNION

            SELECT hospitalization_id AS hospitalization_id
            FROM PRESCRIPTION
            WHERE s.staff_id = staff_id
        )
    ) AS average_total_expierience
FROM STAFF s
WHERE s.staff_id = ?"
        ),
        5 => array(
            'title' => '5. Top young surgeons',
            'params' => array(),
            'sql' => "SELECT d.staff_id, st.first_name, st.last_name
FROM DOCTOR d
JOIN STAFF st ON st.staff_id = d.staff_id
JOIN SURGERY s ON s.surgeon_id = d.staff_id
WHERE st.age < 35
GROUP BY d.staff_id, st.first_name, st.last_name, st.age
ORDER BY COUNT(*) DESC
LIMIT 1"
        ),
        6 => array(
            'title' => '6. Patient hospitalization history',
            'params' => array(
                array('name' => 'AMKA', 'label' => 'Patient AMKA', 'type' => 'number', 'default' => '10061102069')
            ),
            'sql' => "SELECT h.department_name,
       h.admission_date,
       h.discharge_date,
       h.admission_diagnosis,
       d1.description,
       h.discharge_diagnosis,
       d2.description,
       h.current_cost,
       he.total_expierience
FROM HOSPITALIZATION h
JOIN TRIAGE t ON h.triage_id = t.triage_id
JOIN DIAGNOSES d1 ON h.admission_diagnosis = d1.diagnosis_code
JOIN DIAGNOSES d2 ON h.discharge_diagnosis = d2.diagnosis_code
JOIN EVALUATION_HOSPITALIZATION he ON h.hospitalization_id = he.hospitalization_id
WHERE t.AMKA = ?"
        ),
        7 => array(
            'title' => '7. Allergies by substance',
            'params' => array(),
            'sql' => "SELECT act.substance_name,
    COUNT(ap.AMKA) AS num_of_allergic_patients,
    (
        SELECT COUNT(*)
        FROM MEDICATION_SUBSTANCE
        WHERE substance_id = act.substance_id
    ) AS num_of_medication_with_substance
FROM ALLERGIC_PATIENTS AS ap
RIGHT OUTER JOIN ACTIVE_SUBSTANCE AS act ON ap.substance_id = act.substance_id
GROUP BY act.substance_id
ORDER BY num_of_allergic_patients DESC"
        ),
        8 => array(
            'title' => '8. Staff free on date',
            'params' => array(
                array('name' => 'dept_name', 'label' => 'Department', 'type' => 'text', 'default' => 'Cardiology'),
                array('name' => 'shift_day', 'label' => 'Shift date', 'type' => 'date', 'default' => '2026-05-10')
            ),
            'sql' => "SELECT s.AMKA,
       s.last_name,
       s.first_name,
       s.staff_type
FROM (
    SELECT dd.staff_id AS staff_id
    FROM DOCTOR_DEPARTMENT dd
    WHERE dd.department_name = ?

    UNION

    SELECT n.staff_id
    FROM NURSES n
    WHERE n.department_name = ?

    UNION

    SELECT adm.staff_id
    FROM ADMINISTRATIVE_STAFF adm
    WHERE adm.department_name = ?
) AS department_staff_id
JOIN STAFF s ON s.staff_id = department_staff_id.staff_id
WHERE NOT EXISTS (
    SELECT 1
    FROM DUTY_TEAM dt
    JOIN SHIFTS sh ON dt.shift_id = sh.shift_id
    WHERE s.staff_id = dt.staff_id
    AND sh.shift_date = ?
    AND sh.department_name = ?
)"
        ),
        9 => array(
            'title' => '9. Same yearly stay days',
            'params' => array(),
            'sql' => "WITH Patient_Yearly_Stay AS (
    SELECT
        YEAR(h.admission_date) AS the_year,
        p.first_name,
        p.last_name,
        p.AMKA,
        SUM(DATEDIFF(h.discharge_date, h.admission_date)) AS total_days
    FROM PATIENTS p
    JOIN TRIAGE t ON p.AMKA = t.AMKA
    JOIN HOSPITALIZATION h ON t.triage_id = h.triage_id
    WHERE h.discharge_date IS NOT NULL
    GROUP BY YEAR(h.admission_date), p.AMKA, p.first_name, p.last_name
    HAVING SUM(DATEDIFF(h.discharge_date, h.admission_date)) > 15
),
Same_Durations AS (
    SELECT the_year, total_days
    FROM Patient_Yearly_Stay
    GROUP BY the_year, total_days
    HAVING COUNT(*) > 1
)
SELECT p1.*
FROM Patient_Yearly_Stay p1
JOIN Same_Durations p2 ON p1.the_year = p2.the_year AND p1.total_days = p2.total_days
ORDER BY p1.the_year, p1.total_days, p1.last_name"
        ),
        10 => array(
            'title' => '10. Frequent substance pairs',
            'params' => array(),
            'sql' => "SELECT ms1.substance_id AS substance_id_1,
       ms2.substance_id AS substance_id_2,
       asub1.substance_name AS substance_name_1,
       asub2.substance_name AS substance_name_2,
       COUNT(DISTINCT p1.hospitalization_id) AS frequency
FROM MEDICATION_SUBSTANCE ms1
JOIN PRESCRIPTION p1 ON p1.medication_id = ms1.medication_id
JOIN PRESCRIPTION p2 ON p2.hospitalization_id = p1.hospitalization_id
JOIN MEDICATION_SUBSTANCE ms2 ON p2.medication_id = ms2.medication_id AND ms1.substance_id < ms2.substance_id
JOIN ACTIVE_SUBSTANCE asub1 ON ms1.substance_id = asub1.substance_id
JOIN ACTIVE_SUBSTANCE asub2 ON ms2.substance_id = asub2.substance_id
GROUP BY ms1.substance_id, ms2.substance_id
ORDER BY frequency DESC
LIMIT 3"
        ),
        11 => array(
            'title' => '11. Doctors below top surgeries',
            'params' => array(),
            'sql' => "WITH doc_surgeries AS (
    SELECT sur.surgeon_id, COUNT(*) AS total_surgeries
    FROM SURGERY sur
    JOIN HOSPITALIZATION_PROCEDURE hp ON sur.surgery_id = hp.procedure_hospitalization_id
    WHERE YEAR(hp.procedure_start_time) = YEAR(CURRENT_DATE)
    GROUP BY sur.surgeon_id
)
SELECT
    s.AMKA,
    s.first_name,
    s.last_name,
    COALESCE(ds.total_surgeries, 0) AS surgeries_done
FROM STAFF s
JOIN DOCTOR d ON s.staff_id = d.staff_id
LEFT OUTER JOIN doc_surgeries ds ON s.staff_id = ds.surgeon_id
WHERE COALESCE(ds.total_surgeries, 0) <= (
    SELECT MAX(total_surgeries) - 5
    FROM doc_surgeries
)
ORDER BY surgeries_done ASC"
        ),
        12 => array(
            'title' => '12. Staff per weekly shift',
            'params' => array(
                array('name' => 'week_start', 'label' => 'Week start', 'type' => 'date', 'default' => '2026-05-04')
            ),
            'sql' => "SELECT
    sh.department_name,
    sh.shift_date,
    sh.slot,
    all_personnel.staff_type,
    all_personnel.subtype,
    COUNT(*) AS number_of_personnel
FROM SHIFTS sh
JOIN DUTY_TEAM dt ON sh.shift_id = dt.shift_id
JOIN
(
    SELECT staff_id, 'doctor' AS staff_type, specialty AS subtype
    FROM DOCTOR

    UNION ALL

    SELECT staff_id, 'nurse' AS staff_type, `rank` AS subtype
    FROM NURSES

    UNION ALL

    SELECT staff_id, 'administrative staff' AS staff_type, role AS subtype
    FROM ADMINISTRATIVE_STAFF
) AS all_personnel ON dt.staff_id = all_personnel.staff_id
WHERE sh.shift_date >= ?
AND sh.shift_date < DATE_ADD(?, INTERVAL 7 DAY)
GROUP BY
    sh.department_name,
    sh.shift_date,
    sh.slot,
    all_personnel.staff_type,
    all_personnel.subtype
ORDER BY
    sh.department_name,
    sh.shift_date,
    sh.slot,
    all_personnel.staff_type"
        ),
        13 => array(
            'title' => '13. Doctor supervisor chains',
            'params' => array(),
            'sql' => "WITH RECURSIVE supervisor_chain AS (
    SELECT
        d.staff_id AS start_doc,
        d.staff_id AS current_doc,
        d.supervisor,
        dr.description AS doctor_ranks,
        0 AS lvl
    FROM DOCTOR d
    JOIN DOCTOR_RANKS dr ON dr.`rank` = d.`rank`

    UNION ALL

    SELECT
        sc.start_doc,
        d.staff_id AS current_doc,
        d.supervisor,
        dr.description AS doctor_ranks,
        sc.lvl + 1 AS lvl
    FROM supervisor_chain sc
    JOIN DOCTOR d ON d.staff_id = sc.supervisor
    JOIN DOCTOR_RANKS dr ON dr.`rank` = d.`rank`
)
SELECT *
FROM supervisor_chain
ORDER BY start_doc, lvl"
        ),
        14 => array(
            'title' => '14. Repeated diagnosis counts',
            'params' => array(),
            'sql' => "WITH number_of_diagnoses_per_year AS (
    SELECT
        admission_diagnosis AS diagnosis_category,
        COUNT(*) AS number_of_cases,
        YEAR(admission_date) AS diag_year
    FROM HOSPITALIZATION
    GROUP BY admission_diagnosis, YEAR(admission_date)
    HAVING COUNT(*) >= 5
)
SELECT DISTINCT nd1.diagnosis_category
FROM number_of_diagnoses_per_year nd1
WHERE EXISTS (
    SELECT 1
    FROM number_of_diagnoses_per_year nd2
    WHERE nd1.diagnosis_category = nd2.diagnosis_category
    AND nd1.number_of_cases = nd2.number_of_cases
    AND nd1.diag_year = nd2.diag_year - 1
)"
        ),
        15 => array(
            'title' => '15. Triage urgency stats',
            'params' => array(),
            'sql' => "WITH urgency_level_stats AS (
    SELECT
        tr.urgency_level,
        COUNT(*) AS number_of_cases,
        AVG(TIMESTAMPDIFF(MINUTE, tr.arrival_time, tr.service_time)) AS avg_wait_time,
        (COUNT(ho.hospitalization_id) * 100.0 / COUNT(*)) AS admission_percentage
    FROM TRIAGE tr
    LEFT OUTER JOIN HOSPITALIZATION ho ON tr.triage_id = ho.triage_id
    GROUP BY tr.urgency_level
),
department_urg_level_stats AS (
    SELECT
        tr.urgency_level,
        ho.department_name,
        COUNT(*) AS dept_referrals
    FROM TRIAGE tr
    LEFT OUTER JOIN HOSPITALIZATION ho ON tr.triage_id = ho.triage_id
    GROUP BY tr.urgency_level, ho.department_name
)
SELECT
    uls.urgency_level,
    uls.number_of_cases,
    uls.admission_percentage,
    ds.department_name,
    ds.dept_referrals
FROM urgency_level_stats uls
JOIN department_urg_level_stats ds ON uls.urgency_level = ds.urgency_level
ORDER BY uls.urgency_level ASC, ds.dept_referrals DESC"
        )
    );
}
?>
