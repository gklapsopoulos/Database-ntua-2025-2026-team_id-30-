<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `hospitalization` ORDER BY `hospitalization_id` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospitalization</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Hospitalization</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_hospitalization.php">Create Hospitalization</a>
        <span class="muted">Showing up to 300 rows from hospitalization</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>hospitalization_id</th>
                    <th>triage_id</th>
                    <th>department_name</th>
                    <th>bed_id</th>
                    <th>admission_diagnosis</th>
                    <th>discharge_diagnosis</th>
                    <th>admission_date</th>
                    <th>discharge_date</th>
                    <th>current_cost</th>
                    <th>drg_code</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="11">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['triage_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['department_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['bed_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['admission_diagnosis'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['discharge_diagnosis'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['admission_date'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['discharge_date'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['current_cost'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['drg_code'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_hospitalization.php?hospitalization_id=<?php echo urlencode($row['hospitalization_id']); ?>">Edit</a>
                                <a class="btn danger" href="delete_hospitalization.php?hospitalization_id=<?php echo urlencode($row['hospitalization_id']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
