<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `department` ORDER BY `department_name` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Department</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Department</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_department.php">Create Department</a>
        <span class="muted">Showing up to 300 rows from department</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>department_name</th>
                    <th>description</th>
                    <th>floor</th>
                    <th>building</th>
                    <th>bed_count</th>
                    <th>director_id</th>
                    <th>media_id</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="8">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['department_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['description'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['floor'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['building'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['bed_count'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['director_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['media_id'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_department.php?department_name=<?php echo urlencode($row['department_name']); ?>">Edit</a>
                                <a class="btn danger" href="delete_department.php?department_name=<?php echo urlencode($row['department_name']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
