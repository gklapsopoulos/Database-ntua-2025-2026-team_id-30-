<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $descriptionValue = "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";
    $categoryValue = "'" . mysqli_real_escape_string($conn, $_POST['category']) . "'";
    $costValue = "'" . mysqli_real_escape_string($conn, $_POST['cost']) . "'";
    $procedure_codeKey = mysqli_real_escape_string($conn, $_POST['procedure_code'] ?? '');
    $where = "`procedure_code` = '$procedure_codeKey'";

    $sql = "UPDATE `medical_procedures` SET `description` = $descriptionValue, `category` = $categoryValue, `cost` = $costValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: medical_procedures.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $procedure_codeKey = mysqli_real_escape_string($conn, $_GET['procedure_code'] ?? '');
    $where = "`procedure_code` = '$procedure_codeKey'";
$result = mysqli_query($conn, "SELECT * FROM `medical_procedures` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Medical Procedure</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Medical Procedure</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>procedure_code: VARCHAR(250); primary key; required</li>
            <li>description: VARCHAR(400); required</li>
            <li>category: VARCHAR(150); required</li>
            <li>cost: INT; required</li>
            <li>Primary key: procedure_code</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="medical_procedures.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="procedure_code" value="<?php echo htmlspecialchars($row['procedure_code'] ?? ''); ?>">

            <label>
                procedure_code
                <input type="text" name="procedure_code" value="<?php echo htmlspecialchars($row['procedure_code'] ?? ''); ?>" required disabled>
            </label>

            <label>
                description
                <input type="text" name="description" value="<?php echo htmlspecialchars($row['description'] ?? ''); ?>" required>
            </label>

            <label>
                category
                <input type="text" name="category" value="<?php echo htmlspecialchars($row['category'] ?? ''); ?>" required>
            </label>

            <label>
                cost
                <input type="number" name="cost" value="<?php echo htmlspecialchars($row['cost'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="medical_procedures.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
