<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `patients` ORDER BY `AMKA` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patients</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Patients</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_patients.php">Create Patient</a>
        <span class="muted">Showing up to 300 rows from patients</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>AMKA</th>
                    <th>last_name</th>
                    <th>first_name</th>
                    <th>father_name</th>
                    <th>age</th>
                    <th>gender</th>
                    <th>weight</th>
                    <th>height</th>
                    <th>street</th>
                    <th>street_number</th>
                    <th>city</th>
                    <th>insurance_provider</th>
                    <th>email</th>
                    <th>profession</th>
                    <th>nationality</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="16">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['AMKA'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['last_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['first_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['father_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['age'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['gender'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['weight'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['height'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['street'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['street_number'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['city'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['insurance_provider'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['email'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['profession'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['nationality'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_patients.php?AMKA=<?php echo urlencode($row['AMKA']); ?>">Edit</a>
                                <a class="btn danger" href="delete_patients.php?AMKA=<?php echo urlencode($row['AMKA']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
