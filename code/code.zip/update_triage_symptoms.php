<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $triage_idKey = mysqli_real_escape_string($conn, $_POST['triage_id'] ?? '');
    $symptomKey = mysqli_real_escape_string($conn, $_POST['symptom'] ?? '');
    $where = "`triage_id` = '$triage_idKey' AND `symptom` = '$symptomKey'";

    $sql = "UPDATE `triage_symptoms` SET  WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: triage_symptoms.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $triage_idKey = mysqli_real_escape_string($conn, $_GET['triage_id'] ?? '');
    $symptomKey = mysqli_real_escape_string($conn, $_GET['symptom'] ?? '');
    $where = "`triage_id` = '$triage_idKey' AND `symptom` = '$symptomKey'";
$result = mysqli_query($conn, "SELECT * FROM `triage_symptoms` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Triage Symptom</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Triage Symptom</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>symptom: VARCHAR(50); primary key; required</li>
            <li>triage_id: INT; primary key; required; must already exist in TRIAGE(triage_id)</li>
            <li>Primary key: triage_id, symptom</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="triage_symptoms.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="triage_id" value="<?php echo htmlspecialchars($row['triage_id'] ?? ''); ?>">
                <input type="hidden" name="symptom" value="<?php echo htmlspecialchars($row['symptom'] ?? ''); ?>">

            <label>
                symptom
                <input type="text" name="symptom" value="<?php echo htmlspecialchars($row['symptom'] ?? ''); ?>" required disabled>
            </label>

            <label>
                triage_id
                <input type="number" name="triage_id" value="<?php echo htmlspecialchars($row['triage_id'] ?? ''); ?>" required disabled>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="triage_symptoms.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
