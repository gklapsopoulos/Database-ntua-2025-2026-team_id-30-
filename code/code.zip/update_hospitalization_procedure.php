<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $procedure_start_timeValue = "'" . mysqli_real_escape_string($conn, $_POST['procedure_start_time']) . "'";
    $procedure_end_timeValue = "'" . mysqli_real_escape_string($conn, $_POST['procedure_end_time']) . "'";
    $procedure_durationValue = "'" . mysqli_real_escape_string($conn, $_POST['procedure_duration']) . "'";
    $procedure_codeValue = "'" . mysqli_real_escape_string($conn, $_POST['procedure_code']) . "'";
    $hospitalization_idValue = "'" . mysqli_real_escape_string($conn, $_POST['hospitalization_id']) . "'";
    $room_idValue = "'" . mysqli_real_escape_string($conn, $_POST['room_id']) . "'";
    $procedure_hospitalization_idKey = mysqli_real_escape_string($conn, $_POST['procedure_hospitalization_id'] ?? '');
    $where = "`procedure_hospitalization_id` = '$procedure_hospitalization_idKey'";

    $sql = "UPDATE `hospitalization_procedure` SET `procedure_start_time` = $procedure_start_timeValue, `procedure_end_time` = $procedure_end_timeValue, `procedure_duration` = $procedure_durationValue, `procedure_code` = $procedure_codeValue, `hospitalization_id` = $hospitalization_idValue, `room_id` = $room_idValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: hospitalization_procedure.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $procedure_hospitalization_idKey = mysqli_real_escape_string($conn, $_GET['procedure_hospitalization_id'] ?? '');
    $where = "`procedure_hospitalization_id` = '$procedure_hospitalization_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `hospitalization_procedure` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Hospitalization Procedure</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Hospitalization Procedure</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>procedure_hospitalization_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>procedure_start_time: DATETIME; required</li>
            <li>procedure_end_time: DATETIME; required</li>
            <li>procedure_duration: INT; required</li>
            <li>procedure_code: VARCHAR(250); required; must already exist in MEDICAL_PROCEDURES(procedure_code)</li>
            <li>hospitalization_id: INT; required; must already exist in HOSPITALIZATION(hospitalization_id)</li>
            <li>room_id: INT; required; must already exist in OPERATING_ROOM(room_id)</li>
            <li>Primary key: procedure_hospitalization_id</li>
            <li>Unique: hospitalization_id, procedure_start_time, procedure_end_time</li>
            <li>Check: procedure_end_time &gt; procedure_start_time</li>
            <li>Check: MINUTE(procedure_start_time) = 0 AND SECOND(procedure_start_time) = 0</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="hospitalization_procedure.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="procedure_hospitalization_id" value="<?php echo htmlspecialchars($row['procedure_hospitalization_id'] ?? ''); ?>">

            <label>
                procedure_hospitalization_id
                <input type="number" name="procedure_hospitalization_id" value="<?php echo htmlspecialchars($row['procedure_hospitalization_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                procedure_start_time
                <input type="datetime-local" name="procedure_start_time" value="<?php echo htmlspecialchars($row['procedure_start_time'] ?? ''); ?>" required>
            </label>

            <label>
                procedure_end_time
                <input type="datetime-local" name="procedure_end_time" value="<?php echo htmlspecialchars($row['procedure_end_time'] ?? ''); ?>" required>
            </label>

            <label>
                procedure_duration
                <input type="number" name="procedure_duration" value="<?php echo htmlspecialchars($row['procedure_duration'] ?? ''); ?>" required>
            </label>

            <label>
                procedure_code
                <input type="text" name="procedure_code" value="<?php echo htmlspecialchars($row['procedure_code'] ?? ''); ?>" required>
            </label>

            <label>
                hospitalization_id
                <input type="number" name="hospitalization_id" value="<?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?>" required>
            </label>

            <label>
                room_id
                <input type="number" name="room_id" value="<?php echo htmlspecialchars($row['room_id'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="hospitalization_procedure.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
