<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $roleValue = "'" . mysqli_real_escape_string($conn, $_POST['role']) . "'";
    $officeValue = "'" . mysqli_real_escape_string($conn, $_POST['office']) . "'";
    $staff_idValue = "'" . mysqli_real_escape_string($conn, $_POST['staff_id']) . "'";
    $department_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['department_name']) . "'";

    $sql = "INSERT INTO `administrative_staff` (`role`, `office`, `staff_id`, `department_name`) VALUES ($roleValue, $officeValue, $staff_idValue, $department_nameValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: administrative_staff.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Administrative Staff</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Administrative Staff</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>role: VARCHAR(30); required</li>
            <li>office: VARCHAR(10); required</li>
            <li>staff_id: INT; primary key; required; must already exist in STAFF(staff_id)</li>
            <li>department_name: VARCHAR(50); required; must already exist in DEPARTMENT(department_name)</li>
            <li>Primary key: staff_id</li>
            <li>Check: role IN (&#039;Admissions Officer&#039;, &#039;Department Secretary&#039;, &#039;Appointment Scheduler&#039;, &#039;Accountant&#039;, &#039;Billing Specialist&#039;, &#039;HR Officer&#039;, &#039;Procurement Officer&#039;, &#039;Inventory Manager&#039;, &#039;Administrative Director&#039;, &#039;IT Support Officer&#039;)</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                role
                <select name="role" required>
                    <option value="Admissions Officer">Admissions Officer</option>
                    <option value="Department Secretary">Department Secretary</option>
                    <option value="Appointment Scheduler">Appointment Scheduler</option>
                    <option value="Accountant">Accountant</option>
                    <option value="Billing Specialist">Billing Specialist</option>
                    <option value="HR Officer">HR Officer</option>
                    <option value="Procurement Officer">Procurement Officer</option>
                    <option value="Inventory Manager">Inventory Manager</option>
                    <option value="Administrative Director">Administrative Director</option>
                    <option value="IT Support Officer">IT Support Officer</option>
                </select>
            </label>

            <label>
                office
                <input type="text" name="office" required>
            </label>

            <label>
                staff_id
                <input type="number" name="staff_id" required>
            </label>

            <label>
                department_name
                <input type="text" name="department_name" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="administrative_staff.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
