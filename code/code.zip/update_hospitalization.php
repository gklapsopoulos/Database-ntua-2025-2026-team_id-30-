<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $triage_idValue = "'" . mysqli_real_escape_string($conn, $_POST['triage_id']) . "'";
    $department_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['department_name']) . "'";
    $bed_idValue = "'" . mysqli_real_escape_string($conn, $_POST['bed_id']) . "'";
    $admission_diagnosisValue = "'" . mysqli_real_escape_string($conn, $_POST['admission_diagnosis']) . "'";
    $discharge_diagnosisValue = "'" . mysqli_real_escape_string($conn, $_POST['discharge_diagnosis']) . "'";
    $admission_dateValue = "'" . mysqli_real_escape_string($conn, $_POST['admission_date']) . "'";
    $discharge_dateValue = ($_POST['discharge_date'] === '') ? "NULL" : "'" . mysqli_real_escape_string($conn, $_POST['discharge_date']) . "'";
    $current_costValue = "'" . mysqli_real_escape_string($conn, $_POST['current_cost']) . "'";
    $drg_codeValue = "'" . mysqli_real_escape_string($conn, $_POST['drg_code']) . "'";
    $hospitalization_idKey = mysqli_real_escape_string($conn, $_POST['hospitalization_id'] ?? '');
    $where = "`hospitalization_id` = '$hospitalization_idKey'";

    $sql = "UPDATE `hospitalization` SET `triage_id` = $triage_idValue, `department_name` = $department_nameValue, `bed_id` = $bed_idValue, `admission_diagnosis` = $admission_diagnosisValue, `discharge_diagnosis` = $discharge_diagnosisValue, `admission_date` = $admission_dateValue, `discharge_date` = $discharge_dateValue, `current_cost` = $current_costValue, `drg_code` = $drg_codeValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: hospitalization.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $hospitalization_idKey = mysqli_real_escape_string($conn, $_GET['hospitalization_id'] ?? '');
    $where = "`hospitalization_id` = '$hospitalization_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `hospitalization` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Hospitalization</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Hospitalization</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>hospitalization_id: INT; primary key; required; auto increment, you can leave it empty</li>
            <li>triage_id: INT; required; unique value; must already exist in TRIAGE(triage_id)</li>
            <li>department_name: VARCHAR(50); required; must already exist in DEPARTMENT(department_name)</li>
            <li>bed_id: INT; required; must already exist in BEDS(bed_number)</li>
            <li>admission_diagnosis: VARCHAR(250); required; must already exist in DIAGNOSES(diagnosis_code)</li>
            <li>discharge_diagnosis: VARCHAR(250); required; must already exist in DIAGNOSES(diagnosis_code)</li>
            <li>admission_date: DATE; required</li>
            <li>discharge_date: DATE; can be empty/NULL</li>
            <li>current_cost: INT; required</li>
            <li>drg_code: VARCHAR(50); required; must already exist in DRG(drg_code)</li>
            <li>Primary key: hospitalization_id</li>
            <li>Check: discharge_date IS NULL OR admission_date &lt; discharge_date</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="hospitalization.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="hospitalization_id" value="<?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?>">

            <label>
                hospitalization_id
                <input type="number" name="hospitalization_id" value="<?php echo htmlspecialchars($row['hospitalization_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                triage_id
                <input type="number" name="triage_id" value="<?php echo htmlspecialchars($row['triage_id'] ?? ''); ?>" required>
            </label>

            <label>
                department_name
                <input type="text" name="department_name" value="<?php echo htmlspecialchars($row['department_name'] ?? ''); ?>" required>
            </label>

            <label>
                bed_id
                <input type="number" name="bed_id" value="<?php echo htmlspecialchars($row['bed_id'] ?? ''); ?>" required>
            </label>

            <label>
                admission_diagnosis
                <input type="text" name="admission_diagnosis" value="<?php echo htmlspecialchars($row['admission_diagnosis'] ?? ''); ?>" required>
            </label>

            <label>
                discharge_diagnosis
                <input type="text" name="discharge_diagnosis" value="<?php echo htmlspecialchars($row['discharge_diagnosis'] ?? ''); ?>" required>
            </label>

            <label>
                admission_date
                <input type="date" name="admission_date" value="<?php echo htmlspecialchars($row['admission_date'] ?? ''); ?>" required>
            </label>

            <label>
                discharge_date
                <input type="date" name="discharge_date" value="<?php echo htmlspecialchars($row['discharge_date'] ?? ''); ?>">
            </label>

            <label>
                current_cost
                <input type="number" name="current_cost" value="<?php echo htmlspecialchars($row['current_cost'] ?? ''); ?>" required>
            </label>

            <label>
                drg_code
                <input type="text" name="drg_code" value="<?php echo htmlspecialchars($row['drg_code'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="hospitalization.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
