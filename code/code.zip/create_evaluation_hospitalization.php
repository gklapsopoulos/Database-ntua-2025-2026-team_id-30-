<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $hospitalization_idValue = "'" . mysqli_real_escape_string($conn, $_POST['hospitalization_id']) . "'";
    $cleanlinessValue = "'" . mysqli_real_escape_string($conn, $_POST['cleanliness']) . "'";
    $nursing_care_qualityValue = "'" . mysqli_real_escape_string($conn, $_POST['nursing_care_quality']) . "'";
    $food_qualityValue = "'" . mysqli_real_escape_string($conn, $_POST['food_quality']) . "'";
    $total_expierienceValue = "'" . mysqli_real_escape_string($conn, $_POST['total_expierience']) . "'";

    $sql = "INSERT INTO `evaluation_hospitalization` (`hospitalization_id`, `cleanliness`, `nursing_care_quality`, `food_quality`, `total_expierience`) VALUES ($hospitalization_idValue, $cleanlinessValue, $nursing_care_qualityValue, $food_qualityValue, $total_expierienceValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: evaluation_hospitalization.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Evaluation Hospitalization</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Evaluation Hospitalization</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>hospitalization_id: INT; primary key; required; must already exist in HOSPITALIZATION(hospitalization_id)</li>
            <li>cleanliness: INT; required</li>
            <li>nursing_care_quality: INT; required</li>
            <li>food_quality: INT; required</li>
            <li>total_expierience: INT; required</li>
            <li>Primary key: hospitalization_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                hospitalization_id
                <input type="number" name="hospitalization_id" required>
            </label>

            <label>
                cleanliness
                <input type="number" name="cleanliness" required>
            </label>

            <label>
                nursing_care_quality
                <input type="number" name="nursing_care_quality" required>
            </label>

            <label>
                food_quality
                <input type="number" name="food_quality" required>
            </label>

            <label>
                total_expierience
                <input type="number" name="total_expierience" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="evaluation_hospitalization.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
