<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $department_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['department_name']) . "'";
    $staff_idValue = "'" . mysqli_real_escape_string($conn, $_POST['staff_id']) . "'";

    $sql = "INSERT INTO `doctor_department` (`department_name`, `staff_id`) VALUES ($department_nameValue, $staff_idValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: doctor_department.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Doctor Department</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Doctor Department</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>department_name: VARCHAR(50); primary key; required; must already exist in DEPARTMENT(department_name)</li>
            <li>staff_id: INT; primary key; required; must already exist in DOCTOR(staff_id)</li>
            <li>Primary key: staff_id, department_name</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                department_name
                <input type="text" name="department_name" required>
            </label>

            <label>
                staff_id
                <input type="number" name="staff_id" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="doctor_department.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
