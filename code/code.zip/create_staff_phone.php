<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $phoneValue = "'" . mysqli_real_escape_string($conn, $_POST['phone']) . "'";
    $staff_idValue = "'" . mysqli_real_escape_string($conn, $_POST['staff_id']) . "'";

    $sql = "INSERT INTO `staff_phone` (`phone`, `staff_id`) VALUES ($phoneValue, $staff_idValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: staff_phone.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Staff Phone</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Staff Phone</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>phone: VARCHAR(20); primary key; required</li>
            <li>staff_id: INT; primary key; required; must already exist in STAFF(staff_id)</li>
            <li>Primary key: phone, staff_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                phone
                <input type="text" name="phone" required>
            </label>

            <label>
                staff_id
                <input type="number" name="staff_id" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="staff_phone.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
