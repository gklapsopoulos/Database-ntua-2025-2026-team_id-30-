<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $rankKey = mysqli_real_escape_string($conn, $_POST['rank'] ?? '');
    $where = "`rank` = '$rankKey'";
    $sql = "DELETE FROM `doctor_ranks` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: doctor_ranks.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $rankKey = mysqli_real_escape_string($conn, $_GET['rank'] ?? '');
    $where = "`rank` = '$rankKey'";
$result = mysqli_query($conn, "SELECT * FROM `doctor_ranks` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Doctor Rank</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Doctor Rank</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="doctor_ranks.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Doctor Ranks?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>rank:</strong> <?php echo htmlspecialchars($row['rank'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="rank" value="<?php echo htmlspecialchars($row['rank'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="doctor_ranks.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
