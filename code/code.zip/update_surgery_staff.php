<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $staff_idKey = mysqli_real_escape_string($conn, $_POST['staff_id'] ?? '');
    $procedure_hospitalization_idKey = mysqli_real_escape_string($conn, $_POST['procedure_hospitalization_id'] ?? '');
    $where = "`staff_id` = '$staff_idKey' AND `procedure_hospitalization_id` = '$procedure_hospitalization_idKey'";

    $sql = "UPDATE `surgery_staff` SET  WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: surgery_staff.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $staff_idKey = mysqli_real_escape_string($conn, $_GET['staff_id'] ?? '');
    $procedure_hospitalization_idKey = mysqli_real_escape_string($conn, $_GET['procedure_hospitalization_id'] ?? '');
    $where = "`staff_id` = '$staff_idKey' AND `procedure_hospitalization_id` = '$procedure_hospitalization_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `surgery_staff` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Surgery Staff</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Surgery Staff</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>staff_id: INT; primary key; required; must already exist in STAFF(staff_id)</li>
            <li>procedure_hospitalization_id: INT; primary key; required; must already exist in hospitalization_procedure(procedure_hospitalization_id)</li>
            <li>Primary key: staff_id, procedure_hospitalization_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="surgery_staff.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>">
                <input type="hidden" name="procedure_hospitalization_id" value="<?php echo htmlspecialchars($row['procedure_hospitalization_id'] ?? ''); ?>">

            <label>
                staff_id
                <input type="number" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                procedure_hospitalization_id
                <input type="number" name="procedure_hospitalization_id" value="<?php echo htmlspecialchars($row['procedure_hospitalization_id'] ?? ''); ?>" required disabled>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="surgery_staff.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
