<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $rankValue = "'" . mysqli_real_escape_string($conn, $_POST['rank']) . "'";
    $staff_idValue = "'" . mysqli_real_escape_string($conn, $_POST['staff_id']) . "'";
    $department_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['department_name']) . "'";

    $sql = "INSERT INTO `nurses` (`rank`, `staff_id`, `department_name`) VALUES ($rankValue, $staff_idValue, $department_nameValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: nurses.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Nurse</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Nurse</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>rank: VARCHAR(20); required</li>
            <li>staff_id: INT; primary key; required; must already exist in STAFF(staff_id)</li>
            <li>department_name: VARCHAR(50); required; must already exist in DEPARTMENT(department_name)</li>
            <li>Primary key: staff_id</li>
            <li>Check: `rank` IN (&#039;nursing assistant&#039;, &#039;nurse&#039;, &#039;head nurse&#039;)</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                rank
                <select name="rank" required>
                    <option value="nursing assistant">nursing assistant</option>
                    <option value="nurse">nurse</option>
                    <option value="head nurse">head nurse</option>
                </select>
            </label>

            <label>
                staff_id
                <input type="number" name="staff_id" required>
            </label>

            <label>
                department_name
                <input type="text" name="department_name" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="nurses.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
