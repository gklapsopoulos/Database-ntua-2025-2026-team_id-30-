<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $surgeon_idValue = "'" . mysqli_real_escape_string($conn, $_POST['surgeon_id']) . "'";
    $surgery_idKey = mysqli_real_escape_string($conn, $_POST['surgery_id'] ?? '');
    $where = "`surgery_id` = '$surgery_idKey'";

    $sql = "UPDATE `surgery` SET `surgeon_id` = $surgeon_idValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: surgery.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $surgery_idKey = mysqli_real_escape_string($conn, $_GET['surgery_id'] ?? '');
    $where = "`surgery_id` = '$surgery_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `surgery` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Surgery</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Surgery</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>surgeon_id: INT; required; must already exist in DOCTOR(staff_id)</li>
            <li>surgery_id: INT; primary key; required; must already exist in HOSPITALIZATION_PROCEDURE(procedure_hospitalization_id)</li>
            <li>Primary key: surgery_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="surgery.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="surgery_id" value="<?php echo htmlspecialchars($row['surgery_id'] ?? ''); ?>">

            <label>
                surgeon_id
                <input type="number" name="surgeon_id" value="<?php echo htmlspecialchars($row['surgeon_id'] ?? ''); ?>" required>
            </label>

            <label>
                surgery_id
                <input type="number" name="surgery_id" value="<?php echo htmlspecialchars($row['surgery_id'] ?? ''); ?>" required disabled>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="surgery.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
