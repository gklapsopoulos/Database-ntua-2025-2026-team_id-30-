<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['delete'])) {
    $medication_idKey = mysqli_real_escape_string($conn, $_POST['medication_id'] ?? '');
    $substance_idKey = mysqli_real_escape_string($conn, $_POST['substance_id'] ?? '');
    $where = "`medication_id` = '$medication_idKey' AND `substance_id` = '$substance_idKey'";
    $sql = "DELETE FROM `medication_substance` WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: medication_substance.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $medication_idKey = mysqli_real_escape_string($conn, $_GET['medication_id'] ?? '');
    $substance_idKey = mysqli_real_escape_string($conn, $_GET['substance_id'] ?? '');
    $where = "`medication_id` = '$medication_idKey' AND `substance_id` = '$substance_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `medication_substance` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Medication Substance</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Delete Medication Substance</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="card">
        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="medication_substance.php">Back</a>
        <?php else: ?>
            <h2>Delete row from Medication Substance?</h2>
            <p class="muted">Primary key:</p>
            <ul>
                <li><strong>medication_id:</strong> <?php echo htmlspecialchars($row['medication_id'] ?? ''); ?></li>
                <li><strong>substance_id:</strong> <?php echo htmlspecialchars($row['substance_id'] ?? ''); ?></li>
            </ul>

            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <p class="muted">This usually means another table still references this row.</p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="medication_id" value="<?php echo htmlspecialchars($row['medication_id'] ?? ''); ?>">
                <input type="hidden" name="substance_id" value="<?php echo htmlspecialchars($row['substance_id'] ?? ''); ?>">

                <div class="form-actions">
                    <button class="danger" type="submit" name="delete">Delete</button>
                    <a class="btn secondary" href="medication_substance.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
