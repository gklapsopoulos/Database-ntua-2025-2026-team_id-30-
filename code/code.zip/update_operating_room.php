<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $media_idValue = "'" . mysqli_real_escape_string($conn, $_POST['media_id']) . "'";
    $descriptionValue = "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";
    $room_idKey = mysqli_real_escape_string($conn, $_POST['room_id'] ?? '');
    $where = "`room_id` = '$room_idKey'";

    $sql = "UPDATE `operating_room` SET `media_id` = $media_idValue, `description` = $descriptionValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: operating_room.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $room_idKey = mysqli_real_escape_string($conn, $_GET['room_id'] ?? '');
    $where = "`room_id` = '$room_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `operating_room` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Operating Room</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Operating Room</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>room_id: INT; primary key; required</li>
            <li>media_id: INT; required; must already exist in MEDIA_OPERATING_ROOMS(media_id)</li>
            <li>description: VARCHAR(200); required</li>
            <li>Primary key: room_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="operating_room.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="room_id" value="<?php echo htmlspecialchars($row['room_id'] ?? ''); ?>">

            <label>
                room_id
                <input type="number" name="room_id" value="<?php echo htmlspecialchars($row['room_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                media_id
                <input type="number" name="media_id" value="<?php echo htmlspecialchars($row['media_id'] ?? ''); ?>" required>
            </label>

            <label>
                description
                <input type="text" name="description" value="<?php echo htmlspecialchars($row['description'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="operating_room.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
