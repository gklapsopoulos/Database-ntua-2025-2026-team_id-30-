<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `triage_symptoms` ORDER BY `triage_id`, `symptom` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Triage Symptoms</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Triage Symptoms</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_triage_symptoms.php">Create Triage Symptom</a>
        <span class="muted">Showing up to 300 rows from triage_symptoms</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>symptom</th>
                    <th>triage_id</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="3">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['symptom'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['triage_id'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_triage_symptoms.php?triage_id=<?php echo urlencode($row['triage_id']); ?>&symptom=<?php echo urlencode($row['symptom']); ?>">Edit</a>
                                <a class="btn danger" href="delete_triage_symptoms.php?triage_id=<?php echo urlencode($row['triage_id']); ?>&symptom=<?php echo urlencode($row['symptom']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
