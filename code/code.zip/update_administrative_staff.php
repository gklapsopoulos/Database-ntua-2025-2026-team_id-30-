<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['update'])) {
    $roleValue = "'" . mysqli_real_escape_string($conn, $_POST['role']) . "'";
    $officeValue = "'" . mysqli_real_escape_string($conn, $_POST['office']) . "'";
    $department_nameValue = "'" . mysqli_real_escape_string($conn, $_POST['department_name']) . "'";
    $staff_idKey = mysqli_real_escape_string($conn, $_POST['staff_id'] ?? '');
    $where = "`staff_id` = '$staff_idKey'";

    $sql = "UPDATE `administrative_staff` SET `role` = $roleValue, `office` = $officeValue, `department_name` = $department_nameValue WHERE $where";

    if (mysqli_query($conn, $sql)) {
        header("Location: administrative_staff.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}

    $staff_idKey = mysqli_real_escape_string($conn, $_GET['staff_id'] ?? '');
    $where = "`staff_id` = '$staff_idKey'";
$result = mysqli_query($conn, "SELECT * FROM `administrative_staff` WHERE $where LIMIT 1");
$row = $result ? mysqli_fetch_assoc($result) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Administrative Staff</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Update Administrative Staff</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>role: VARCHAR(30); required</li>
            <li>office: VARCHAR(10); required</li>
            <li>staff_id: INT; primary key; required; must already exist in STAFF(staff_id)</li>
            <li>department_name: VARCHAR(50); required; must already exist in DEPARTMENT(department_name)</li>
            <li>Primary key: staff_id</li>
            <li>Check: role IN (&#039;Admissions Officer&#039;, &#039;Department Secretary&#039;, &#039;Appointment Scheduler&#039;, &#039;Accountant&#039;, &#039;Billing Specialist&#039;, &#039;HR Officer&#039;, &#039;Procurement Officer&#039;, &#039;Inventory Manager&#039;, &#039;Administrative Director&#039;, &#039;IT Support Officer&#039;)</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <?php if (!$row): ?>
            <p class="error">Row not found.</p>
            <a class="btn secondary" href="administrative_staff.php">Back</a>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>">

            <label>
                role
                <select name="role" required>
                    <option value="Admissions Officer" <?php echo $row['role'] === 'Admissions Officer' ? 'selected' : ''; ?>>Admissions Officer</option>
                    <option value="Department Secretary" <?php echo $row['role'] === 'Department Secretary' ? 'selected' : ''; ?>>Department Secretary</option>
                    <option value="Appointment Scheduler" <?php echo $row['role'] === 'Appointment Scheduler' ? 'selected' : ''; ?>>Appointment Scheduler</option>
                    <option value="Accountant" <?php echo $row['role'] === 'Accountant' ? 'selected' : ''; ?>>Accountant</option>
                    <option value="Billing Specialist" <?php echo $row['role'] === 'Billing Specialist' ? 'selected' : ''; ?>>Billing Specialist</option>
                    <option value="HR Officer" <?php echo $row['role'] === 'HR Officer' ? 'selected' : ''; ?>>HR Officer</option>
                    <option value="Procurement Officer" <?php echo $row['role'] === 'Procurement Officer' ? 'selected' : ''; ?>>Procurement Officer</option>
                    <option value="Inventory Manager" <?php echo $row['role'] === 'Inventory Manager' ? 'selected' : ''; ?>>Inventory Manager</option>
                    <option value="Administrative Director" <?php echo $row['role'] === 'Administrative Director' ? 'selected' : ''; ?>>Administrative Director</option>
                    <option value="IT Support Officer" <?php echo $row['role'] === 'IT Support Officer' ? 'selected' : ''; ?>>IT Support Officer</option>
                </select>
            </label>

            <label>
                office
                <input type="text" name="office" value="<?php echo htmlspecialchars($row['office'] ?? ''); ?>" required>
            </label>

            <label>
                staff_id
                <input type="number" name="staff_id" value="<?php echo htmlspecialchars($row['staff_id'] ?? ''); ?>" required disabled>
            </label>

            <label>
                department_name
                <input type="text" name="department_name" value="<?php echo htmlspecialchars($row['department_name'] ?? ''); ?>" required>
            </label>

                <div class="form-actions">
                    <button type="submit" name="update">Save</button>
                    <a class="btn secondary" href="administrative_staff.php">Back</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
