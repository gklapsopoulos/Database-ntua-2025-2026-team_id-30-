<?php
function quoteIdentifier($name) {
    return '`' . str_replace('`', '``', $name) . '`';
}

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function tableTitle($table) {
    return ucwords(strtolower(str_replace('_', ' ', $table)));
}

function getTables($conn) {
    $tables = array();
    $result = mysqli_query($conn, "SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'");
    if ($result) {
        while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
            $tables[] = $row[0];
        }
    }
    sort($tables);
    return $tables;
}

function bindValues($stmt, $values) {
    if (count($values) === 0) {
        return;
    }
    $types = str_repeat('s', count($values));
    $refs = array($types);
    foreach ($values as $index => $value) {
        $refs[] = &$values[$index];
    }
    call_user_func_array(array($stmt, 'bind_param'), $refs);
}

function displayValue($value) {
    if ($value === null) {
        return '';
    }
    return h($value);
}

?>
