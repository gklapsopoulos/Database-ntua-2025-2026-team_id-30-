<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $phoneValue = "'" . mysqli_real_escape_string($conn, $_POST['phone']) . "'";
    $relative_idValue = "'" . mysqli_real_escape_string($conn, $_POST['relative_id']) . "'";

    $sql = "INSERT INTO `relative_phone` (`phone`, `relative_id`) VALUES ($phoneValue, $relative_idValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: relative_phone.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Relative Phone</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Relative Phone</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>phone: VARCHAR(20); primary key; required</li>
            <li>relative_id: INT; primary key; required; must already exist in PATIENT_RELATIVES(relative_id) ON DELETE CASCADE</li>
            <li>Primary key: phone, relative_id</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                phone
                <input type="text" name="phone" required>
            </label>

            <label>
                relative_id
                <input type="number" name="relative_id" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="relative_phone.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
