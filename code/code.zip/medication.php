<?php
include 'db_connection.php';

$conn = OpenCon();
$result = mysqli_query($conn, "SELECT * FROM `medication` ORDER BY `medication_id` LIMIT 300");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medication</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Medication</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="toolbar">
        <a class="btn" href="create_medication.php">Create Medication</a>
        <span class="muted">Showing up to 300 rows from medication</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>medication_id</th>
                    <th>product_name</th>
                    <th>route_of_administration</th>
                    <th>product_authorisation_country</th>
                    <th>marketing_authorisation_holder</th>
                    <th>pharmacovigilance_system_master_file_location</th>
                    <th>pharmacovigilance_email</th>
                    <th>pharmacovigilance_phone</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$result || mysqli_num_rows($result) === 0): ?>
                    <tr><td colspan="9">No rows found.</td></tr>
                <?php else: ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['medication_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['product_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['route_of_administration'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['product_authorisation_country'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['marketing_authorisation_holder'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['pharmacovigilance_system_master_file_location'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['pharmacovigilance_email'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['pharmacovigilance_phone'] ?? ''); ?></td>
                            <td class="actions">
                                <a class="btn secondary" href="update_medication.php?medication_id=<?php echo urlencode($row['medication_id']); ?>">Edit</a>
                                <a class="btn danger" href="delete_medication.php?medication_id=<?php echo urlencode($row['medication_id']); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
