<?php
include 'db_connection.php';

$conn = OpenCon();
$error = '';

if (isset($_POST['create'])) {
    $drg_codeValue = "'" . mysqli_real_escape_string($conn, $_POST['drg_code']) . "'";
    $descriptionValue = "'" . mysqli_real_escape_string($conn, $_POST['description']) . "'";
    $costValue = "'" . mysqli_real_escape_string($conn, $_POST['cost']) . "'";
    $average_length_of_stayValue = "'" . mysqli_real_escape_string($conn, $_POST['average_length_of_stay']) . "'";

    $sql = "INSERT INTO `drg` (`drg_code`, `description`, `cost`, `average_length_of_stay`) VALUES ($drg_codeValue, $descriptionValue, $costValue, $average_length_of_stayValue)";

    if (mysqli_query($conn, $sql)) {
        header("Location: drg.php");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Drg</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav id="nav-bar">
    <div id="navbar-div">
        <a id="nav-bar-text">Hospital Database Demo - Create Drg</a>
        <a id="navbar-items" href="/hospital_app/">Landing</a>
    </div>
</nav>
<main class="container">
    <div class="help-box">
        <h3>Allowed values / constraints</h3>
        <ul>
            <li>drg_code: VARCHAR(50); primary key; required</li>
            <li>description: VARCHAR(255); required</li>
            <li>cost: INT; required</li>
            <li>average_length_of_stay: INT; required</li>
            <li>Primary key: drg_code</li>
            <li>Check: cost &gt;= 0</li>
            <li>Check: average_length_of_stay &gt;= 0</li>
        </ul>
    </div>

    <div class="card">
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>
                drg_code
                <input type="text" name="drg_code" required>
            </label>

            <label>
                description
                <input type="text" name="description" required>
            </label>

            <label>
                cost
                <input type="number" name="cost" required>
            </label>

            <label>
                average_length_of_stay
                <input type="number" name="average_length_of_stay" required>
            </label>

            <div class="form-actions">
                <button type="submit" name="create">Create</button>
                <a class="btn secondary" href="drg.php">Back</a>
            </div>
        </form>
    </div>
</main>
</body>
</html>

<?php CloseCon($conn); ?>
